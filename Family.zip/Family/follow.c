#include<stdio.h>
#include<ctype.h>
#include<string.h>
char ps[10][10];
int i,j,n,m=0;
int nof;
void addres(char c);
void first(char c);
void follow(char);
int main(){
char result[10];
char c;
int ch;
  printf("Enter no.of productions");
  scanf("%d",&nof);
  printf("Enter productions");
  for(i=0;i<nof;i++){
    scanf("%s",ps[i]);
  }
  do{
    printf("Enter character");
    scanf("%c",&c);
    scanf("%c",&c);
    follow(c);
    printf("\nFollow(%c)is",c);
    for(i=0;i<m;i++){
      printf("%c",result[i]);
    }
    printf("}\n");
    printf("Enter your choice");
    scanf("%d",&ch);
    //scanf("%d",&ch);
  }
  while(ch==1);
}
void follow(char c){
  if(ps[0][0]==c){
    addres('$');
  }
  for(i=0;i<nof;i++){
    for(j=2;j<strlen(ps[i]);j++){
      if(ps[i][j]==c){
        if(ps[i][j+1]=='\0'){
          follow(ps[i][0]);
        }
         if(ps[i][j+1]!='\0'){
          first(ps[i][j+1]);
        }
        
      }
    }
  }
}
void first(char c){
int k;
 if(!(isupper(c))){
  addres(c);
 }
 for(k=0;k<nof;k++){
   if(ps[k][0]==c){
     if(ps[k][2]=='$'){
       follow(ps[k][0]);
     }
     else if(islower(ps[k][2])){
     
      addres(ps[k][2]);
     }
     else{
       first(ps[k][2]);
     }
   }
 }
 
}
void addres(char c){
int k;
 for(k=0;k<=m;k++){
   if(result[k]==c){
     return;
   }
 }
 result[m++]=c;
}


