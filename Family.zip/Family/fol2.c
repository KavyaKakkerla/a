#include<stdio.h>
#include<ctype.h>
#include<string.h>
void first(char c);
void follow(char c);
void addres(char);
char ps[10][10];
char result[10];
int i,j,n,m=0;
int main(){
  char c;
  int ch;
  int i;
  printf("EBter no.of productions");
  scanf("%d",&n);
  for(i=0;i<n;i++){
    scanf("%s",ps[i]);
  }
  do{
   m=0;
    printf("Enter the character");
    scanf("%c",&c);
    scanf("%c",&c);
    follow(c);
    printf("follow(%c)--->",c);
    for(i=0;i<m;i++){
      printf("%c",result[i]);
    }
    printf("}\n");
    printf("Enter your choice");
    scanf("%d",&ch);
  }
  while(ch==1);
}
void follow(char c){
  if(ps[0][0]==c){
    addres('$');
  }
  for(i=0;i<n;i++){
    for(j=2;j<strlen(ps[i]);j++){
      if(ps[i][j]==c){
        if(ps[i][j+1]!='\0'){
          first(ps[i][j+1]);
        }
          if(ps[i][j+1]=='\0'&& c!=ps[i][0]){
          follow(ps[i][0]);
        }
      }
    }
  }
}
void first(char c){
int i;
 if(!(isupper(c))){
  addres(c);
 }
 for(i=0;i<n;i++){
   if(ps[i][0]==c){
    if(ps[i][2]=='$'){
      follow(ps[i][0]);
    }
    else if(islower(ps[i][2])){
      addres(ps[i][2]);
    }
    else{
      first(ps[i][2]);
    }
   }
 }
}

void addres(char c){
int k;
for(k=0;k<=m;k++){
 if(result[k]==c){
   return;
 }
}
result[m++]=c;
}
