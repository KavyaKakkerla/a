%{
 #include<stdio.h>
 int fl=0;
%}
%token id
%%
exp:exp exp '*'
exp:exp exp '+'
exp:id
;
%%
int main(){
 yyparse();
 if(fl==0){
  printf("valid expression:");
 }
}
void yyerror(){
 printf("Invalid expression:");
 fl=1;
}
