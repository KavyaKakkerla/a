%{
 #include<stdio.h>
 int fl=0;
%}
%token NUMBER
%left '+''-'
%left '*''/''%'
%left '('')'
%%
ArithmeticExpression:E{printf("\nResult=%d\n",$$);
return 0;
}
E:E'+'E {$$=$1+$3;}
|E'-'E {$$=$1-$3;}
|E'*'E {$$=$1*$3;}
|E'/'E {$$=$1/$3;}
|E'%'E {$$=$1%$3;}
|'('E')'{$$=$2;}
|NUMBER {$$=$1;}
;
%%
void main(){
 printf("\nEnter any Arihtmetic expression which have operations\n");
yyparse();
 if(fl==0){
   printf("\nEntered Arithmetic expression is valid");
 }
}
void yyerror(){
 printf("Entered Arithmetic expression is invalid");
 fl=1;
}
