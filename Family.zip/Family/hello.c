#include<stdio.h>
void main(){
//I am a good girl
printf("hellobro");
//Give your best at every point of your life;
}

