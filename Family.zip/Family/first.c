#include<stdio.h>
#include<ctype.h>
void first(char[],char);
void addres(char[],char);
int nof;
char ps[10][10];
int main(){
 int i;
 char c;
 int ch;
 char result[20];
 printf("Enter no.of productions");
 scanf("%d",&nof);
 // printf("Enter no.of productions");
 for(i=0;i<nof;i++){
  printf("Enter productions %d",i);
  scanf("%s",ps[i]);
  }
  do{
     printf("\nEnter character");
     scanf("%c",&c);
     scanf("%c",&c);
     first(result,c);
     printf("\n First(%c){",c);
     for(i=0;result[i]!='\0';i++){
       printf("%c",result[i]);
     }
     printf("}\n");
     printf("\nEnter your choice");
     scanf("%d",&ch);
  }
  while(ch==1);
}
void first(char *result,char c){
 int i,j,k;
 int fe;
 char subres[20];
 subres[0]='\0';
 result[0]='\0';
 if(!(isupper(c))){
   addres(result,c);
   return;
 }
 for(i=0;i<nof;i++){
   if(ps[i][0]==c){
     if(ps[i][2]=='$'){
       addres(result,'$');
       return;
     }
     else{
      j=2;
      while(ps[i][j]!='\0'){
        fe=0;
        first(subres,ps[i][j]);
        for(k=0;subres[k]!='\0';k++){
          addres(result,subres[k]);
        }
        for(k=0;subres[k]!='\0';k++){
          if(subres[k]=='$'){
            fe=1;
            break;
          }
        }
        if(!fe){
         break;
        }
        j++; 
      } 
   }
}
}
return;
}
void addres(char result[],char val){
int k;
 for(k=0;result[k]!='\0';k++){
   if(result[k]==val){
    return;
   }
 }
 result[k]=val;
 result[k+1]='\0';
}
