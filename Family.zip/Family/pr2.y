%{
 #include<stdio.h>
 int fl=0;
%}
%token type ID
%%
D:T' 'L;
T:type;
L:L ','ID|ID;
%%
int main(){
 printf("Enter the expression\n");
 yyparse();
 printf("validexpression\n");
}
void yyerror(char *s){
 
}

