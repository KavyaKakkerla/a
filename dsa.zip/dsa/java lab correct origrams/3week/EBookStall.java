
import java.util.Scanner;

class Book {
    private String bookName;
    private String bookAuthor;
    public int bookCount;

    public Book(String bookName, String bookAuthor, int bookCount) {
        this.bookName = bookName;
        this.bookAuthor = bookAuthor;
        this.bookCount = bookCount;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthorName() {
        return bookAuthor;
    }

    public int getBookCount() {
        return bookCount;
    }

    void display() {
        System.out.printf("\nAuthor of the book: %s\nNo of books available: %d\n", bookAuthor, bookCount);
    }
}

class Customer {
    private int customerID;
    private String customerName;
    private String customerAddress;

    public Customer(int customerID, String customerName, String customerAddress) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
    }

    public void buyBook(Book b[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Book name you want to purchase: ");
        String name = sc.next();
        for (int i = 0; i < b.length; i++) {
            String s = b[i].getBookName();
            if (name.equals(s)) {
                if (b[i].getBookCount() == 0)
                    System.out.println("That book is out of Stock");
                else {
                    
                    b[i].bookCount--;
                    b[i].display();
                }

                System.out.println("Customer " + customerName + " has bought a book " + b[i].getBookName());
            }
        }
    }
}

public class Main {
    public static void main(String args[]) {
        System.out.println("Welcome to BookStall");
        System.out.println("Enter Details below");
        System.out.println("*************Books*************");
        System.out.println("Enter no of books in the stall");
        Scanner sc = new Scanner(System.in);
        int nob = sc.nextInt();
        Book[] b = new Book[nob];
        System.out.println("Enter details of book[x] in order\n 1) name of book\n 2)Author of the book\n3) No of books available");
        for (int i = 0; i < nob; i++) {
            System.out.print("Details of book[" + (i + 1) + "]: ");
            b[i] = new Book(sc.next(), sc.next(), sc.nextInt());
        }
        Customer student = new Customer(1, "Madhavi", "Warangal");
        student.buyBook(b);
    }
}

/*import java.util.Scanner;
class Book
{
	private String bookName;
	private String bookAuthor;
	private int bookCount;
	
	
	public Book(String bookName,String bookAuthor,int bookCount)
	{
		this.bookName=bookName;
		this.bookAuthor=bookAuthor;
		this.bookCount=bookCount;
	}
	public String getBookName()
	{
		return bookName;
	}
	public String getAuthotName()
	{
	 	return bookAuthor;
	}
	public int getBookCount()
	{
		return bookCount;
	}
	public void sellBook()
	{
		if(bookCount>0)
		{
			bookCount--;
			System.out.println("BOOK "+bookName+"sold. Remainin count :"+bookCount);
		}
		else
		{
			System.out.println("Sorry The book is not available");
		}
	}
}


class Customer
{
	private int customerID;
	private String customerName;
	private String customerAddress;
	
	public Customer(int customerID,String customerName,String customerAddres)
	{
		this.customerID=customerID;
		this.customerName=customerName;
		this.customerAddress=customerAddress;
	}
	public void buyBook(Book book)
	{
		System.out.println("Customer "+customerName+"is buying a book");
			
		book.sellBook();
		
	}
}


public class EBookStall
{

	public static void main(String args[])
	{
		Book textbook=new Book("introduction to java","kavya kakkerla",10);
		Customer student=new Customer(1,"MAdhavi","Warangal");
		student.buyBook(textbook);
	}
}*/
