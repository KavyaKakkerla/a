import java.util.Scanner;

public class Employee
{
	int id;
	String name;
	int age;
	String gender;
	String designation;
	double salary;
	String address;
	
	public Employee(int id,String name,int age,String gender,String designation,double salary,String address)
	{
		this.id=id;
		this.name=name;
		this.age=age;
		this.gender=gender;
		this.designation=designation;
		this.salary=salary;
		this.address=address;
	}
	public void display()
	{
		System.out.println(id+" "+name+" "+age);
	}
	public static void main(String args[])
	{	
		Scanner sc=new Scanner(System.in);
		
		int n=5;
		Employee e[]=new Employee[n];
		e[0]=new Employee(1,"kavya",22,"female","ceo",2000000,"warangal");
		e[1]=new Employee(2,"madhavi",22,"female","ceo",2000000,"warangal");
		e[2]=new Employee(3,"ramesh",22,"female","ceo",2000000,"warangal");
		e[3]=new Employee(4,"rishi",22,"female","ceo",2000000,"warangal");
		e[4]=new Employee(5,"sravani",22,"female","ceo",2000000,"warangal");
		System.out.println("Enetr the i dyou want");
		int m=sc.nextInt();
		int flag=0;
		for(int i=0;i<n;i++)
		{
		   	if(m==e[i].id)
			{
				e[i].display();
				flag=1;
				break;
			}
			
		}
		if(flag==0)
		{
		    System.out.println("not found");
		}
	}
}
