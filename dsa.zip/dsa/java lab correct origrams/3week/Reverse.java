

import java.util.Scanner;



public class Reverse{
    public static void main(String  args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("ENter the string :");
        String text=sc.nextLine();
        String rev="";
        char ch;
        for(int i=0;i<text.length();i++)
        {
        	ch=text.charAt(i);
        	rev=ch+rev;
        
      	}
      	System.out.println("reversed string is "+rev);
    }
    
}
/*
public static String reverseString(String input) {
        int length = input.length();
        StringBuilder reversed = new StringBuilder();

        // Traverse the input string from the end to the beginning
        for (int i = length - 1; i >= 0; i--) {
            // Append each character to the StringBuilder in reverse order
            reversed.append(input.charAt(i));
        }

        // Convert the StringBuilder back to a String
        return reversed.toString();
    }*/
