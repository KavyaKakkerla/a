import java.util.Scanner;

class comparestring
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Eneter the first string :");
        String first_string=sc.nextLine();
        System.out.println("Eneter the second string :");
        String second_string=sc.nextLine();
        int result=first_string.compareTo(second_string);
        if(result<0)
        {
            System.out.println("The first sring comes before second string");

        }
        else if(result>0)
        {
            System.out.println("The first sring comes after second string");
            
        }
        else
        {
            System.out.println("The first sring and second string are equal");
            
        }
    }
}