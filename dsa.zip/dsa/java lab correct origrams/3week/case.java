public class ChangeCaseDemo {

    public static void changeCase(String input) {
        // Convert the given string to uppercase
        String upperCaseString = input.toUpperCase();

        // Display the string in uppercase
        System.out.println("String in Uppercase: " + upperCaseString);

        // Convert the string in uppercase back to lowercase
        String lowerCaseString = upperCaseString.toLowerCase();

        // Display the string in lowercase
        System.out.println("String in Lowercase: " + lowerCaseString);
    }

    public static void main(String[] args) {
        String givenString = "This is a Sample String.";

        // Change the case of the given string and display both versions
        changeCase(givenString);
    }
}

