import java.util.Scanner;
 private static void vowelcount(String text) {
    
 int vowelCount=0;
        int ConCount=0;
        for(int i=0;i<text.length();i++)
        {
            char ch=text.charAt(i);
            if(Character.isLetter(ch))
            {
                if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
                {
                    System.out.println(ch+" ");
                    vowelCount++;
                }
                else
                {
                    ConCount++;
                }
            }
        }
            System.out.println("number of vowels"+vowelCount);
            System.out.println("number of consonant"+ConCount);
        }




public class vowelConsonantcount

{
    public static void main(String args[])
    {
         Scanner sc=new Scanner(System.in);
        System.out.println("ENter the string :");
        String text=sc.nextLine().toLowerCase();
        vowelcount(text);     
    }
    
}
