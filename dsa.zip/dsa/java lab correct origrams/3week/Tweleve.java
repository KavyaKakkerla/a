import java.util.Scanner;
import java.util.HashSet;

public class Tweleve
{
		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			HashSet<Integer> UnqInt=new HashSet<>();
			System.out.println("Eneter any 5 number between 10 and 100 (inclusive)");
			for(int i=0;i<5;i++)
			{
				System.out.println("Enter the "+i+1+"number ");
			int num=sc.nextInt();
			if(isValidNumber(num,UnqInt))
			{
				UnqInt.add(num);
				displayUnqNum(UnqInt);
			}
			else
			{
				System.out.println("Duplictae number! Enter the another number ");
				i--;
			}
			}
		System.out.println("Proram Completed.Unique numbers Are"+UnqInt);
}

private static boolean isValidNumber(int number,HashSet<Integer>UnqInt)
{
	return(number>=10&&number<=100)&&(!UnqInt.contains(number));
}
public static void displayUnqNum(HashSet<Integer>UnqNum)
{
	System.out.println("Unique Numbers enetrred So far"+UnqNum);
}
}
