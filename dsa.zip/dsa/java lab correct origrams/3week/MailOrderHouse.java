/*import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

class Product
{	
	private String name;
	private double price;
	private int quantity;
	
	public Product(String name,double price)
	{
		this.name=name;
		this.price=price;
		
	}
	
	
	
	public void setProQuantity(int quantity)
	{	
		this.quantity=quantity;
	}
	public double getPrice()
	{
		return price*quantity;
	}
	public void show()
	{
		System.out.println("Name of the product "+name);
		System.out.println("Price of the product"+price);
		System.out.println("Quantity of the product"+quantity);
}
}


public class MailOrderHouse
{
	public static void main(String [] args)
	{
		Map<Integer,Product>products=new HashMap<>();
		products.put(1,new Product("kavya 1",99.90));
		products.put(2,new Product("kavya 2",20.20));
		products.put(3,new Product("kavya 3",6.87));
		products.put(4,new Product("kavya 4",45.50));
		products.put(5,new Product("kavya 5",40.49));
		
		double total=0.0;
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enetr pairs of Product id and quantity sold(0 to exit)");
		while(true)
		{
			System.out.println("Product Id :");
			int productId=sc.nextInt();
			
			
			if(productId==0)
			{
				break;
			}
			
			System.out.println("Quantity Sold");
			int quanSold=sc.nextInt();
			
			double retailValue=calretailValue(productId,quanSold,products);
			total+=retailValue;
			System.out.println("total ratail value "+total);
		}
		System.out.println("program excuted success fully total retail value is "+total);
}

public static double calretailValue(int productId,int quanSold,Map<Integer,Product>products)
{
	double value=0.0;
	if(products.containsKey(productId))
	{
		Product product=products.get(productId);
		product.setProQuantity(quanSold);
		value=product.getPrice();
	}
	else
	{
		System.out.println("Invaldi Product ID. please enetr the valid product id");
	}
	return value;
}
}
		
*/

import java.util.Scanner;
//import java.util.HashMap;
//import java.util.Map;

class Product
{	
	private String name;
	private double price;
	public int quantity;
	private int product_id;
	
	public Product(int product_id,String name,int quantity,double price)
	{
		this.product_id=product_id;
		
		this.name=name;
		this.quantity=quantity;
		this.price=price;
		
	}
	
	public double getPrice()
	{
		return price;
	}
	public void show()
	{	System.out.println("Name of the productid "+product_id);
		System.out.println("Name of the product "+name);
		System.out.println("Price of the product"+price);
		System.out.println("Quantity of the product "+quantity);
}
			
				
}

/*class buy
{
	public void sell(Product [] pro)
	{
		int cost=0;
		int p,n;
		Scanner sc=new Scanner(System,in);
		do
		{
			System.out.println("ENetr the product id and quantity");
			
		
			p=sc.nextInt();
			switch(p)
			{
				case 1:
				n=sc.nextInt();
				if(n<=pro[p].quantity)
				{
					pro[p].quantity-n;
					cost+=(n*pro[p].price);
				}
				break;
				case 2:
				n=sc.nextInt();
				if(n<=pro[p].quantity)
				{
					pro[p].quantity-n;
					cost+=(n*pro[p].price);
				}
				break;
				case 3:
				n=sc.nextInt();
				if(n<=pro[p].quantity)
				{
					pro[p].quantity-n;
					cost+=(n*pro[p].price);
				}
				break;
				case 4:
				n=sc.nextInt();
				if(n<=pro[p].quantity)
				{
					pro[p].quantity-n;
					cost+=(n*pro[p].price);
				}
				break;
				case 0:
				n=sc.nextInt();
				if(n<=pro[p].quantity)
				{
					pro[p].quantity-n;
					cost+=(n*pro[p].price);
				}
				break;
				
*/					

public class Main
{
	public static void main(String [] args)
	{
		
		Product[] products=new Product[5];
		
		products[0]=new Product(1,"kavya 1",10,99.90);
		products[1]=new Product(2,"kavya 2",20,20.20);
		products[2]=new Product(3,"kavya 3",30,6.87);
		products[3]=new Product(4,"kavya 4",40,45.50);
		products[4]=new Product(5,"kavya 5",50,40.49);
	    Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the number of different types of products");
		int n;
		n=sc.nextInt();
		int[]sum=new int[5];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Product Number(1-5): ");
            int choice = sc.nextInt();
            System.out.println("Enter Product Quantity: ");
            int q = sc.nextInt();
            switch(choice) {
                case 1:
                    sum[0] += q;
                    break;
                case 2:
                    sum[1] += q;
                    break;
                case 3:
                    sum[2] += q;
                    break;
                case 4:
                    sum[3] += q;
                    break;
                case 5:
                    sum[4] += q;
                    break;
                default:
                    System.out.println("Invalid PRoduct ID");
            }
	}
	double totalp=0.0;
	for(int i=0;i<5;i++){
           System.out.println("product "+(i+1)+" RetailPrice: "+(sum[i]*products[i].getPrice()));
           totalp+=sum[i]*products[i].getPrice();
       }
       
}
}



		

		
