

import java.util.Scanner;



public class size {
    public static void main(String  args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("ENter the string :");
        String text=sc.nextLine();
       System.out.println("The length of the string is (in built function) "+text.length());
       char []arr=text.toCharArray();
       int c=0;
       for(char ch:arr)
       {
       	c++;
       }
        
    System.out.println("The length of the string is ( witjput in built function) "+c);
    }
    
}
