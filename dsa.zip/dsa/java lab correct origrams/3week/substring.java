public class SubString{

    public static void findSubstring(String text, String subText) 
    {
    	if(text.contains(subText))
    	{
            System.out.println("The given text contains the substring '" + subText + "'");
            
            if (text.startsWith(subText)) 
            {
                System.out.println("'" + subText + "' is found at the beginning of the given text.");
            }
            if (text.endsWith(subText)) 
            {
                System.out.println("'" + subText + "' is found at the end of the given text.");
            }
        }
        else 
        {
            System.out.println("The given text does not contain the substring '" + subText + "'");
        }
    }

    public static void main(String[] args) {
        String givenText = "This is a sample text. It contains some sample content.";
        String subString = "sample";

        // Find the substring in the given text
        findSubstring(givenText, subString);
    }
}

