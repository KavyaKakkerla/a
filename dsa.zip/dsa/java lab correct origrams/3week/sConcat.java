
import java.util.Scanner;
public class sConcat {
    
    
    public static void main(String  args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("ENter the first string :");
        String text=sc.nextLine();
        System.out.println("ENter the second string :");
        String text2=sc.nextLine();
        String result=text.concat(text2);
        System.out.println(result);
        
     }
    
}

