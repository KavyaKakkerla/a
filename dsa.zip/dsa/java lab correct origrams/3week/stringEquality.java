import java.util.Scanner;

public class stringEquality
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Eneter the first string :");
        String first_string=sc.nextLine();
        System.out.println("Eneter the second string :");
        String second_string=sc.nextLine();
        //
	if(first_string.equals(second_string))
	{
		System.out.println("both the strings are equal(case sensitive)");
	}
	else
	{
		System.out.println("both the strings are not equal(case sensitive)");
	}
	if(first_string.equalsIgnoreCase(second_string))
	{
		System.out.println("both the strings are equal(case insensitive)");
	}
	else
	{
		System.out.println("both the strings are not equal(case insensitive)");
	}
    }
}