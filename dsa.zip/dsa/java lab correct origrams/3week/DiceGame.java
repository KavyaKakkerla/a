import java.util.Random;
class DiceGame
{
	public static void main(String args[])
	{	
			
			int a=10;//total no of atempts
			int s=0;//succesfull attempts
			
			for(int i=0;i<a;i++)
			{	
				int dice1=rollDice();
				int dice2=rollDice();
				System.out.println("Attempt number   "+i+1+"    Dice 1   ="+dice1+"     Dice 2=    "+dice2);
				if(dice1==dice2)
				{
					s++;
					System.out.println("Success full attempt");
				}
						
				try
				{
					Thread.sleep(1000);
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			System.out.println("Succesfull attempts ="+s);
	}
	public static int rollDice()
{
	Random random=new Random();
	return random.nextInt(6)+1;
}
}
