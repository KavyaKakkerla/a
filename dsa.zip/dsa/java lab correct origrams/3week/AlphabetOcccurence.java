

import java.util.Scanner;



public class alphabetOccurence {
    public static void main(String  args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("ENter the string :");
        String text=sc.nextLine();
        System.out.println("ENter the character :");
        char alpha=sc.next().charAt(0);
        int count=0;
        int currentindex=0;
        while (currentindex<text.length())
        {
        	int index=text.indexOf(alpha,currentindex);
        	if(index!=-1)
        	{
        		count++;
        		currentindex=index+1;
        	}
        	else
        	{	
        		break;
        	}
        }
        
        System.out.println("Total occurances of "+alpha+":"+count);
        
    
    }
    
}
