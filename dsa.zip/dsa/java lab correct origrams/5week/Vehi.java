interface Vehicle
{	
	String getCompany();
	String getModel();
	String getType();
	double getConsumption();
	void display();
	//calculateFuel();
}

class FourWheeler implements Vehicle
{	
	String companyname;
	String model;
	String type;
	double consumption;
	public FourWheeler(String companyname,String model,String type)
	{
		this.companyname=companyname;
		this.model=model;
		this.type=type;
		this.consumption=calculateConsumption(type);
	}
	public String getCompany()
	{	
		return companyname;
	}
	public String getModel()
	{
		return model;
	}
	public String getType()
	{
		return type;
	}
	public double getConsumption()
	{
		return consumption;
	}
	public void display()
	{
		System.out.println("Coompany "+getCompany());
		System.out.println("Model: " + getModel());
        System.out.println("Type: " + getType());
        System.out.println("Fuel Consumption: " + getConsumption() + " km/L");
    }
    private double calculateConsumption(String type)
    {
    	switch(type.toLowerCase())
    	{
    		case "petrol":
    			return 14.0;
    		case "diesel":
    			return 22.0;
    		case "cng":
    			return 18.0;
    		default:
    			throw new IllegalArgumentException("iinvalid choice type :"+type);
    	}
    }
  }
  class TwoWheeler implements Vehicle
{	
	String companyname;
	String model;
	String type;
	double consumption;
	double fuel;
	public TwoWheeler(String companyname,String model,String type)
	{
		this.companyname=companyname;
		this.model=model;
		this.type=type;
		this.consumption=calculateConsumption(type);
	}
	public String getCompany()
	{	
		return companyname;
	}
	public String getModel()
	{
		return model;
	}
	public String getType()
	{
		return type;
	}
	public double getConsumption()
	{
		return consumption;
	}
	public void display()
	{
		System.out.println("Coompany "+getCompany());
		System.out.println("Model: " + getModel());
        System.out.println("Type: " + getType());
        System.out.println("Fuel Consumption: " + getConsumption() + " km/L");
    }
    private double calculateConsumption(String type)
    {
    	switch(type.toLowerCase())
    	{
    		case "petrol":
    			return 62.0;
    		case "diesel":
    			return 82.0;
    		case "cng":
    			return 72.0;
    		default:
    			throw new IllegalArgumentException("iinvalid choice type :"+type);
    	}
    }
  }
public class Vehi
{
	public static void main(String args[])
	{
		Vehicle two=new TwoWheeler("Hondaa","Activa","Petrol");
		Vehicle four=new FourWheeler("Toyato","Camry","Diesel");
		two.display();
        //System.out.println(); // Separate the two outputs
        four.display();
      }
}
