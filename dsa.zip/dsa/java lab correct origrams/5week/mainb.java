



interface RBI
{	
	
	
	void personalLoaneligibility();
	void homeLoanEligibility();
	void vehicleLoanEligibilty();
}
abstract class Bank 
{	
	double balance;
	public Bank(double balance)
	{   
	    this.balance=balance;
	}
	
	void credit(double money)
	{	
		balance+=money;
		System.out.println("The amount"+money+"is credited The balance is "+balance);
	}
		
	void debit(double money)
	{
		balance-=money;
		System.out.println("The amount"+money+"is debited The balance is "+balance);
	}
	
	void displayBalance()
	{
		
	//	System.out.println("The acccount number  is "+account_number);
	//	System.out.println("The account name is "+account_name);
		System.out.println("The balance is "+balance);
	}
	
}
class SBI extends Bank implements RBI
{
	
	//double balance;
	int account_number;
	String account_name;
	double annual_income;
	String property;
	String vehicle;
	SBI(double balance,int account_number,String acccount_name,double annual_income,String property,String vehicle)
	{
		super(balance);
		this.account_number=account_number;
		this.account_name=account_name;
		this.annual_income=annual_income;
		this.property=property;
		this.vehicle=vehicle;
	}
	
public 	void personalLoaneligibility()
	{
		if(annual_income>=1000000)
		{
			System.out.println("Hurry! You are elligble for personal loan as your income is greater than 1000000");
		}
		else
		
		{
			System.out.println("Sorry! You Are not elligible for personal loan");
		}
	}
		
	public void homeLoanEligibility()
	{
		if(property.equalsIgnoreCase("yes"))
		{
			System.out.println("Hurry Home loan is ON THE WAY");
		}
		else
		{	
			System.out.println("NO HOME LOAN");
		}
	}
	public void vehicleLoanEligibilty()
	{
	
		if(vehicle.equalsIgnoreCase("yes"))
		{
			System.out.println("Hurry vehicle loan is ON THE WAY");
		}
		else
		{	
			System.out.println("NO  LOAN");
		}
	}
}

/*class HDFC implements RBI
{
	
	double balance;
	int account_number;
	String acccount_name;
	double annual_income;
	String job;
	String vehicle;
	public HDFC(double balance,int account_number,String acccount_name,double annual_income,String job,String vehicle)
	{
		this.balance=balance;
		this.account_number=account_number;
		this.account_name=account_name;
		this.annual_income=annual_income;
		this.job=job;
		this.vehicle=vehicle;
	}
	void credit(double money)
	{	
		balance+=money;
		System.out.println("The amount"+money+"is credited\n"The balance is "+balance);
	}
		
	void debit(double money)
	{
		balance-=money;
		System.out.println("The amount"+money+"is debited\n"The balance is "+balance);
	}
	
	void displayBalance()
	{
		
		System.out.println("The acccount number  is "+account_number);
		System.out.println("The account name is "+account_name);
		System.out.println("The balance is "+balance);
	}
	void personalLoaneligibility()
	{
		if(annual_income>=1000000)
		{
			System.out.println("Hurry! You are elligble for personal loan as your income is greater than 1000000);
		}
		else
		
		{
			System.out.println("Sorry! You Are not elligible for personal loan");
		}
	}
		
	void homeLoanEligibility()
	{
		if(job.equalsIgnoreCase("govt");
		{
			System.out.println("govt job Hurry Home loan is ON THE WAY");
		}
		else
		{	
			System.out.println("private job NO HOME LOAN");
		}
	}
	void vehicleLoanEligibilty()
	{
	
		if(vehicle.equalsIgnoreCase("yes");
		{
			System.out.println("Hurry vehicle loan is ON THE WAY");
		}
		else
		{	
			System.out.println("NO  LOAN");
		}
	}
}
	
class DCB implements RBI
{
	
	double balance;
	int account_number;
	String acccount_name;
	double annual_income;
	String job;
	String medical;
	public DCB(double balance,int account_number,String acccount_name,double annual_income,String job,String vehicle)
	{
		this.balance=balance;
		this.account_number=account_number;
		this.account_name=account_name;
		this.annual_income=annual_income;
		this.job=job;
		this.medical=medical;
	}
	void credit(double money)
	{	
		balance+=money;
		System.out.println("The amount"+money+"is credited\n"The balance is "+balance);
	}
		
	void debit(double money)
	{
		balance-=money;
		System.out.println("The amount"+money+"is debited\n"The balance is "+balance);
	}
	
	void displayBalance()
	{
		
		System.out.println("The acccount number  is "+account_number);
		System.out.println("The account name is "+account_name);
		System.out.println("The balance is "+balance);
	}
	void personalLoaneligibility()
	{
		if(annual_income>=1000000)
		{
			System.out.println("Hurry! You are elligble for personal loan as your income is greater than 1000000);
		}
		else
		
		{
			System.out.println("Sorry! You Are not elligible for personal loan");
		}
	}
		
	void homeLoanEligibility()
	{
		if(job.equalsIgnoreCase("govt");
		{
			System.out.println("govt job Hurry Home loan is ON THE WAY");
		}
		else
		{	
			System.out.println("private job NO HOME LOAN");
		}
	}
	void vehicleLoanEligibilty()
	{
	
		if(vehicle.equalsIgnoreCase("fit");
		{
			System.out.println("medically Hurry vehicle loan is ON THE WAY");
		}
		else
		{	
			System.out.println("As you aree week NO  LOAN");
		}
	}
}

//double balance;
	int account_number;
	String acccount_name;
	double annual_income;
	String property;
	String vehicle;

*/

public class mainb
{	
	public static void main(String args[])
	{
		SBI s1=new SBI(20000,1203,"kavya",500000,"yes","yes");
		s1.credit(200);
		s1.displayBalance();
		s1.debit(10000);
		s1.displayBalance();
		s1.homeLoanEligibility();
		s1.vehicleLoanEligibilty();
	}
}
		
		
	
