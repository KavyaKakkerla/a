import java.util.Scanner;


public class OnlineSale
{
	public static void main(String [] args)
	{
			Scanner sc=new Scanner(System.in);
			System.out.println("WELCOME TO GRAND KAVYA SALE");
			System.out.println("Enetr the product name");
			String pName=sc.nextLine();
			System.out.println("Enter the company");
			String cName=sc.nextLine();
			System.out.println("Enetr the quantity");
			int quan=sc.nextInt();
			System.out.println("Enetr the original price of the producut ");
			double price=sc.nextDouble();
			
			double amazonPrice=calAmazon(pName,cName,quan,price);
			double filpkartPrice=calFilpkart(pName,cName,quan,price);
			if(amazonPrice<filpkartPrice)
			{
				System.out.println("Buy from amazon");
			}
			else
			{
				System.out.println("buy form filpkart");
			}
	}
	
	public static double calAmazon(String pName,String cName,int quan,double price)
	{
		double totalprice=price*quan;
			boolean isHdfcCard=false;
		System.out.println("Do you have HDFC Card? 1 for yes");
			Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		if(s==1)
		{
		
			isHdfcCard=true;
		}
		
		if(isHdfcCard)
		{
			totalprice*=0.9;
		}
		else if(totalprice>=50000)
		{
			totalprice*=0.85;
		}
		return totalprice;
	}
	public static double calFilpkart(String pName,String cName,int quan,double price)
	{
		double totalprice=price*quan;
		boolean isRGUKT=false;
		System.out.println("are you a Rgukt Student? 1 for yes");
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		if(s==1)
		{
		
			isRGUKT=true;
		}
	
		
		if(isRGUKT)
		{
			totalprice*=0.7;
		}
		else if(totalprice>=30000)
		{
			totalprice*=0.95;
		}
		return totalprice;
	
}
}		
		
		
