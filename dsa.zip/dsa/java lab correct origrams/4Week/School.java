

class Person
{
	private String name;
	private String address;
	public Person(String name,String address)
	{
		this.name=name;
		this.address=address;
	}
		
	public String getName()
	{
		return name;
	}
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address=address;
	}
	public String toString()
	{
		return name+"(address"+address+")";
	}
}

class Student extends Person
{
	private int numC;
	private String[] courses;
	private int[] grades;
	private static final int MAX_COURSES=30;
	
	
	public Student(String name,String address)
	{
		super(name,address);
		numC=0;
		courses=new String[MAX_COURSES];
		grades=new int[MAX_COURSES];
	}
	@Override
	public String toString()
	{
		return "Student :"+super.toString();
	}
	
	public void addCourseGrade(String course,int grade)
	{
		courses[numC]=course;
		grades[numC]=grade;
		++numC;
	}
	
	public double getAverageGrade()
	{
		int sum=0;
		for(int i=0;i<numC;i++)
		{
			sum+=grades[i];
		}
		return (double)sum/numC;
	}
}

class Teacher extends Person
{	
	private int numC;
	private String[] courses;
	private static final int MAX_COURSES=5;
	
	public Teacher(String name,String address)
	{
		super(name,address);
		numC=0;
		courses=new String[MAX_COURSES];
	}
	public String toString()
	{	
		return "Teacher :"+super.toString();
	}
	
	public boolean addCourse(String course)
	{	
		for(int i=0;i<numC;i++)
		{
			if(courses[i].equals(course))
				return false;
		}
		courses[numC]=course;
		numC++;
		return true;
	}
	
	public boolean removeCourse(String course)
	{
		boolean found=false;
		
		int c=-1;
		for(int i=0;i<numC;i++)
		{
			if(courses[i].equals(course))
			{
				c=i;
				found=true;
				break;
			}
		}
		if(found)
		{	
			for(int i=c;i<numC-1;i++)
			{
			courses[i]=courses[i+1];
			}
			numC--;
			return true;
		}
		else
		{
		return false;
		}
	}
}

public class School
{
	public static void main(String args[])
	{
	    Student s1=new Student("kavya","warangal");
	s1.addCourseGrade("java",10);
	s1.addCourseGrade("dbms",7);
	System.out.println("Average is "+s1.getAverageGrade());
	
	Teacher t1=new Teacher("Madhavi","pallaruguda");
	System.out.println(t1);
	
	String []courses={"java","maths","java"};
	for(String course:courses)
	{
		if(t1.addCourse(course))
			System.out.println("Course "+course+"  added");
		else
		{
			System.out.println("Courses canont be aded ");
		}
	}
	t1.removeCourse("java");
	}
}

	
	
