class Monster {
    public String name;
    
    public Monster(String name) {
        this.name = name;
    }

    public void attack() {
        System.out.println("i dont know how to attack");
    }
}

class FireMonster extends Monster {
    public FireMonster(String name) {
        super(name);
    }

   @Override
    public void attack() {
        System.out.println(name + "Attacks with fire");
    }
}

class WaterMonster extends Monster {
    public WaterMonster(String name) {
        super(name);
    }

    @Override
    public void attack() {
        System.out.println(name + " attacks with water ");
    }
}
class StoneMonster extends Monster {
    public StoneMonster(String name) {
        super(name);
    }

    @Override
    public void attack() {
        System.out.println(name + " attacks with stones ");
    }
}
public class MonsterGame {
    public static void main(String[] args) {
        Monster monster1 = new FireMonster("Madhavi");
        Monster monster2 = new WaterMonster("Kavya");
Monster monster3 = new StoneMonster("Rishi");
        
        monster1.attack();
        monster2.attack();
        monster3.attack();
    }
}

