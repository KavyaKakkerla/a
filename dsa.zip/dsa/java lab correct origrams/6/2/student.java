import dept.CSE;
import dept.ECE;
import dept.ME;
import dept.CIVIL;

class student
{
	public static void main(String args[])
	{
		CSE c= new CSE();
		ECE e=new ECE();
		ME m=new ME();
		CIVIL ce=new CIVIL();
		System.out.println("THE subjects");
		e.displaySubjects();
		c.displaySubjects();
		m.displaySubjects();
		ce.displaySubjects();
	}
}
		
		
