package dept;

public class CSE implements Subjects
{
	public void displaySubjects()
	{
		System.out.println("CSE SUbjects : DAA, FLAT, DBMS");
	}
}
