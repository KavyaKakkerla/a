package dept;

public class ECE implements Subjects
{
	public void displaySubjects()
	{
		System.out.println("ECE SUbjects : DEC, AEC, VSLI");
	}
}
