package dept;

public class ME implements Subjects
{
	public void displaySubjects()
	{
		System.out.println("ME SUbjects : FM, HM, THERMODYNAMICS");
	}
}
