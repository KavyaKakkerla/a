package dept;

public class CIVIL implements Subjects
{
	public void displaySubjects()
	{
		System.out.println("CIVL SUbjects : MOM, SOM, BMCT");
	}
}
