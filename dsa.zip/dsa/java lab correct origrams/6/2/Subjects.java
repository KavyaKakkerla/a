package dept;


public interface Subjects
{
	void displaySubjects();
}