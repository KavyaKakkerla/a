import cal.calculator;

class casio
{	
	public static void main(String args[])
	{
		calculator c=new calculator(5,4);
		double add=c.Addition();
		double sub=c.Subtraction();
		double mul=c.Multiplication();
		double div=c.Division();
		System.out.println("the addition is "+add);
		System.out.println("the subtracton is "+sub);
		System.out.println("the mutliplication is "+mul);
		System.out.println("the division is "+div);
	}
}
