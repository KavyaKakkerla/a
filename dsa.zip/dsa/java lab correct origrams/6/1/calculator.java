package cal;

public class calculator implements Operation
{	double a;
	double b;
	
	//The constructor calculator(double, double) is not public in the calculator class, and therefore, it cannot be accessed from outside the package.
	public calculator(double a,double b)
	{
	this.a=a;
	this.b=b;
	}
	//ikkada public ani declare cheyyali nduk ante mundu undhi kabbati
	public double Addition()
	{	
		return a+b;
	}
	public double Subtraction()
	{
		return a-b;
	}
	public double Multiplication()
	{	
		return a*b;
	}
	public double Division()
	{	
		return a/b;
	}
}
