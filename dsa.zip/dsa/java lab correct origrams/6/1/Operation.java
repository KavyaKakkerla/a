package cal;


public interface Operation
{
	double Addition();
	double Subtraction();
	double Multiplication();
	double Division();
}



