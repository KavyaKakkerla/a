import sounds.Podcast;
import java.util.Scanner;
public class Play
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Podcast odcast=new Podcast();
		System.out.println("enetr the track");
		String s=sc.next();
		odcast.playDobly(s);
		odcast.playPodcast(s);
	}
}