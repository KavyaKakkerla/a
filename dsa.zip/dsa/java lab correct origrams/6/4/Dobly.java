package sounds;

public interface Dobly
{
	void playDobly(String s);
}

