package sounds; 

public class Podcast implements Dobly
	{	
		public void playPodcast(String s)
		{
			System.out.println("play Podcast sound "+s);
		}
		
		public void playDobly(String s)
		{
			 System.out.println("play Dobly sound "+s);
		}
	}