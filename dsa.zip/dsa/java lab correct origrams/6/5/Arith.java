package complex;

public class Arith
{
	public int rp,ip;
	public Arith()
	{
		rp=0;
		ip=0;
	}
	public Arith(int rp,int ip)
	{
		this.rp=rp;
		this.ip=ip;
	}
	public Arith add(Arith a1,Arith a2)
	{
		return new Arith(a1.rp+a2.rp,a1.ip+a2.ip);
	}
	public Arith sub(Arith a1,Arith a2)
	{
		return new Arith(a1.rp-a2.rp,a1.ip-a2.ip);
	}
}