import complex.Arith;
import java.util.Scanner;
public class Complex
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the real and imaginary part of the first number");
		int real1=sc.nextInt();
		int imz1=sc.nextInt();
		System.out.println("enter the real and imaginary part of the second number");
		int real2=sc.nextInt();
		int imz2=sc.nextInt();
		Arith a1=new Arith(real1,imz1);
		Arith a2=new Arith(real2,imz2);
		Arith addedResult=add(a1,a2);
		System.out.println("a1="+a1.rp+"+"+a1.ip+"i");
		System.out.println("a2="+a2.rp+"+"+a2.ip+"i");	
		System.out.println("added value"+addedResut.rp+"+"+addedResult.ip+"i");
		Arith subResult=sub(a1,a2);
		System.out.println("subtracted value"+subResut.rp+"+"+subResult.ip+"i");
	}
}
		