package admission;

public interface AdmissionCriteria
{
	boolean isEligible(int mathsMarks,int physicsMarks,int chemistryMarks,int englishMarks);
}