//import admission.*;
import admission.Student;
import admission.EngineeringAdmission;
import admission.AdmissionCriteria;
//import java.util.ArrayList;
//import java.util.List;


public class AdmissionProcessor
{
	public static void main(String args[])
	{
		//List<Student> students=new ArrayList<>();
		
		//students.add(new Student("kavya",75,96,75,85));
		//students.add(new Student("amma",95,96,75,85));
		Student[] students=new Student[2];
		students[0]=new Student("kavya", 74, 96, 75, 85);
		students[1]=new Student("MAdhva", 94, 96, 95, 95);


		EngineeringAdmission engineeringAdd=new EngineeringAdmission();
		System.out.println("Eligibele Students");
		for(Student studi:students)
		{
			if(engineeringAdd.isEligible(studi.getMathsMarks(),studi.getPhysicsMarks(),studi.getChemistryMarks(),studi.getEnglishMarks()))
			{
				System.out.println(studi.getName());
			}
		}


	}
}


















