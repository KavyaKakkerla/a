package eight;
public class Reservation implements ReservationCost
{
	public double totalFare(Passenger[] passengers)
	{
		double totalFare=0;
		for(Passenger asi:passengers)	
		{
			if(asi instanceof Child)
			{
				totalFare+=0;
			}
			else if(asi instanceof Student)
			{
				totalFare+=asi.fare*0.7;
			}
			else if(asi instanceof Citizen)
			{
				totalFare+=asi.fare;
			}
			else if(asi instanceof SeniorCitizen)
			{
				totalFare+=asi.fare*0.5;
			}
		}
		return totalFare;
	}
}