package eight;

public class Passenger
{
	double fare;
	public Passenger(double fare)
	{
		this.fare=fare;
	}
}

class Child extends Passenger{
	public Child()
	{
		super(0);
	}
}
class Student extends Passenger{
	public Student(double fare)
	{
		super(fare);
	}
}
class Citizen extends Passenger{
	public Citizen(double fare)
	{
		super(fare);
	}
}
class SeniorCitizen extends Passenger{
	public SeniorCitizen(double fare)
	{
		super(fare);
	}
}