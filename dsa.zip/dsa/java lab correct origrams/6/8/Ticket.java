package eight;


public class Ticket
{
	public static void main(String args[])
	{	

			Passenger[] passengers={
				new Child(),new Student(100),new SeniorCitizen(100),new Citizen(100)};
			ReservationCost reservation=new Reservation();
			System.out.println("total cost "+reservation.totalFare(passengers));
	}
}