package eight;

public interface ReservationCost
{
	double totalFare(Passenger[] passengers);
}