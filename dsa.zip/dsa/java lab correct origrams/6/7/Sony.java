import TVRemote.TV;
import TVRemote.Channel;
import java.util.Scanner;

public class Sony
{
	public static void main(String args[])
	{
		TV remote=new TV();
		System.out.println("press 1 to switch on the tv");
		Scanner sc=new Scanner(System.in);
		int c;
		c=sc.nextInt();
		if(c==1)
		{
			remote.switchON();
			while(true)
			{
				System.out.printf("\n1.STAR sports\n2.NGc \n3.Discovery\n4.Starmovies\n0.Switvh off the tv\n");
				int c2;
				c2=sc.nextInt();
				switch(c2)
				{
					case 1:
					remote.setChannel(new SportsChannel());
					break;
					case 2:
				
        remote.setChannel(new NGC());
        break;
        case 3:
        remote.setChannel(new Discovery());
        break;
        case 4:
        remote.setChannel(new StarMovies());
        break;
	case 0:
        remote.switchOff();
        System.exit(0);
        break;
        default:
        System.out.println("invalifd choice ");
       }
    }
    }
   }
  }
    
