package TVRemote;

public interface Channel
{
	void play();
}

class Sports implements Channel
{
	public void play()
	{
		System.out.println("playing Sports");
	}
}

class NGC implements Channel
{
	public void play()
	{
		System.out.println("NGC");
	}
}

class Discovery implements Channel
{
	public void play()
	{
		System.out.println("Discovery");
	}
}
class StraMovies implements Channel
{	
	public void play()
	{
		System.out.println("Star movies");
	}
}

