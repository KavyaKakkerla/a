package TVRemote;

public interface RemoteControl extends Channel,Switchable
{
	void setChannel(Channel channel);
}
