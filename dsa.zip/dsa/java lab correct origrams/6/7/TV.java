
public class TV extends Channel
{
	private boolean isON;
	private Channel channel;
	public TV()
	{	
		this.isON=false;
		this.channel=null;
	}
	public void switchOn()
	{
		if(!isOn)
		{
			System.out.println("Welconme to TATa Sky");
			isOn=true;
		}
		else
		{
		System.out.println("tv is alreadu on");
		}
	}			
	public void switchOff()
	{
		if(isOn)
		{
			System.out.println("TV is switcuhed off");
			isOn=false;
		}
		else
		{
		System.out.println("tv is alreadu off");
		}
	}
	public void setChannel(Channel c)
	{
		if(isON)
		{	
			channel=c;
			channel.play();
		}
		else
		{
			System.out.println("TURn  on the TV");
		}
	}			
	
	
}