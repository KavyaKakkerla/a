package TVRemote;
public interface Switchable
{
	void switchOff();
	void switchON();
}

