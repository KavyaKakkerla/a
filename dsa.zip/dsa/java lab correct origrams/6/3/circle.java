package shapes;

public class circle
{
	double side;
	public circle(double side)
	{
		this.side=side;
	}
	
	public void area()
	{
		System.out.println("The area of circle is "+Math.PI*side*side);
	}
	public void peri()
	{
		System.out.println("The perimeter of the circle is "+4*Math.PI*side*side);
	}
}