import shapes.Square;
import shapes.circle;
import java.util.Scanner;

public class three
{
	public static void main(String args[])
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1 square 2 for circle 0 for exit");
		while(true)
		{
			int c;
			c=sc.nextInt();
			if(c==1)
			{
				System.out.println("enter the side");
				int side;
				side=sc.nextInt();
				Square s=new Square(side);
				s.area();
				s.peri();
			}
			if(c==2)
			{
				System.out.println("enter the raius");
				double side;
				side=sc.nextDouble();
				circle s=new circle(side);
				s.area();
				s.peri();
			}
			else if(c==0)
			{
				System.exit(0);
			}
		}
	}
}
	
			
			
		