package shapes;

public class Square
{
	int side;
	public Square(int side)
	{
		this.side=side;
	}
	
	public void area()
	{
		System.out.println("The area of square is "+side*side);
	}
	public void peri()
	{
		System.out.println("The perimeter of the square is "+4*side);
	}
}