package meeseva;

public interface Meeseva
{
	public void welcome();
	public void disease(int n[]);
	public void symptoms();
}