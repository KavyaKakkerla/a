package meeseva;
import java.util.List;
public class Myseva implements Meeseva
{
	
	public void welcome()
	{
		System.out.println("-------------Welcome to mmeeseva----------");
	}
	public void disease(int a[])
	{
		int f1=0,f2=0,f3=0,f4=0;
		if(n[0]==1&&n[1]==1&& n[2]==1 && n[3]==1 && n[4]==1)
		{
			f1=1;
		}
		if(n[0]==1&&n[1]==1&& n[2]==1&&  n[4]==1 &&n[5]==1)
		{
			f2=1;
		}
		if(n[0]==1&&n[1]==1&& n[2]==1  && n[7]==1 && n[6]==1)
		{
			f3=1;
		}
		if(n[0]==1&&n[1]==1&& n[2]==1 && n[5]==1 && n[4]==1)
		{
			f4=1;
		}
		/*if(a[0]==1 && a[1]==1 && a[2]==1 && a[3]==1 && a[4]==1)
			f1 = 1;
			if(a[0]==1 && a[1]==1 && a[2]==1 && a[5]==1 && a[4]==1)
				f2=1;
			if(a[0]==1 && a[1]==1 && a[2]==1 && a[7]==1 && a[6]==1)
				f3=1;
		
				if(a[0]==1 && a[1]==1 && a[2]==1 && a[5]==1 && a[4]==1)
			f4=1;*/
			/*List<Integer>l1=new ArrayList<Integer>();
			for(int i=0;i<8;i++)
			{
					if(n[i]==1)
					{
						l1.add(i);
					}
			}
			if(l1.contains(0,1,2,3,4))
			f1=1;*/
		System.out.println("you are suffering from ");
		if(f1==1)
		{
			System.out.println(" Acute pancreatitis (AP)");

		}
		if(f2==1)
		{
			System.out.println(" Appendicitis (A)");

		}
		if(f3==1)
		{
			System.out.println(" Bladder Cancer(BC)");

		}
		if(f4==1)
		{
			System.out.println(" Pancreatic Cancer (PC)");

		}
	}

	public void symptoms()
	{	
		System.out.println("The symtoms are");
		System.out.print("\n1.Stomach ace\t2.Vomiting");
		System.out.print("\n3.low eye sight\t4.Muscle ace");
		System.out.print("\n5.fever\t6.fatigue");
		System.out.print("\n7.skin allegy\t8.low bp");	
	}
}