import meeseva.Myseva;
import java.util.Scanner;

public class six
{
	public static void main(String args[])
	{
		Myseva ms=new Myseva();
		ms.welcome();
		ms.symptoms();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.print("\n\n1.Check disease\n2.exit \n choose otion:");
			int c;

			c=sc.nextInt();
			if(c==2)
				break;
			System.out.println("how many symtoms do u have");
			int nos;
			nos=sc.nextInt();
			System.out.println("eneter Symtomns numbers below");
			int[] sms=new int[8];
			for(int i=0;i<nos;i++)
			{
				int temp=sc.nextInt();
				if(temp<1 || temp>8)
					{
System.out.println("lase enter a valid symptom");
//scontinue;
}
				else

				{
					sms[temp-1]=1;
				}
			}
			ms.disease(sms);
		}
	}
}
			
		