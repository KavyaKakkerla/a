import java.util.Scanner;


interface Bank
{
	boolean credC(String username,String password) throws Exception;
	void credit(double amount);
	void debit(double amount) throws Exception;
	void display();
	void exit();
}

class SBI implements Bank
{	
	String username;
	String password;
	double balance;
	SBI(String u,String p,double b)
	{
		this.username=u;
		this.password=p;
		this.balance=b;
	}
	
	public boolean credC(String username,String password) throws Exception
	{
		if((this.username==username)&&(this.password==password))
		{	
			return true;
		}
		else
		{
			throw new Exception();
		}
	}
	
	public void credit(double amount)
	{
		this.balance+=amount;
		System.out.println("Amount is credited");
	}
	public void debit(double amount) throws Exception
	{	
		if(balance<amount)
		{	
			throw new Exception();
		}
		else
		{	
			this.balance-=amount;
		}
	}
	public void display()
	{
		System.out.println("The balance is "+this.balance);
	}
	public void exit()
	{	
		System.exit(0);
	}
}


public class p4
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("----------------welcome to bank=================");
		System.out.println("Enter the numbe rof users");
		int nou;
		nou=sc.nextInt();
		SBI[] s=new SBI[nou];
		System.out.println("ENetr the details of the employees");
		for(int i=0;i<nou;i++)
		{
			String user;
			System.out.println("Enter the user name ");
			user=sc.nextLine();
			System.out.println("kavya");
			System.out.println("Enter the password");
			String pass;
			pass=sc.nextLine();
			System.out.println("Enter the balance ");
			double balance=sc.nextDouble();
			s[i]=new SBI(user,pass,balance);
		}
		
		
		System.out.println("---------------------welcome---------------");
		System.out.println("Eneter 1 to perform actions 0 to exit-------");
		while(true)
		{
			int n;
			System.out.println("Eneter the cjoice");
			n=sc.nextInt();
			if(n==0)
			{
				sc.close();
				System.exit(0);
			}
			System.out.println("============Enetr your details");
			String u;
			String p;
			System.out.println("enter the user name");
			u=sc.nextLine();
			int f=0;
			for(int i=0;i<nou;i++)
			{
				if(u.equals(s[i].username))
				{
					f=1;
					System.out.println("Enter the password");
					boolean b=false;
					String z;
					z=sc.nextLine();
					try
					{
						b=s[i].credC(u,z);
					}
					catch(Exception e)
					{	
						System.out.println("Wrong credentials");
				}
				
				if(b==true)
				{
				while(true)
				{
					System.out.printf("1.credit\n2.debit\n3.display balance\n4.exit\n");
					int c;
					c=sc.nextInt();
					if(c==1)
					{
						
						System.out.println("Eneter the smount uou want to add");
					s[i].credit(sc.nextDouble());
					}
					else if(c==2)
					{
					    try{
					System.out.println("Eneter the amount ypu eant to take");
					s[i].debit(sc.nextDouble());
					    }
					    catch(Exception e)
					    {
					        System.out.println("Insufficent balance");
					    }
				}
				else if(c==3)
				{
					s[i].display();
				}
				else
				{
					s[i].exit();
				}
			}
		}
		}
	}
	if(f==0)
	{
		System.out.println("user not found");
	}
	}
	

}
}
	
		
			
