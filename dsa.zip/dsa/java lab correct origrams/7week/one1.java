import java.util.InputMismatchException;
import java.util.Scanner;


public class one1
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("ENetr a numeric value :");
			int a=sc.nextInt();
			System.out.println("You entered "+a);
		}
		catch(InputMismatchException e)
		{
			System.out.println("invalid inut.Please enetr a valid input");
			System.out.println("Exception details: " + e.getMessage());
            e.printStackTrace();
		}
		finally
		{
			sc.close();
		}
	}
}