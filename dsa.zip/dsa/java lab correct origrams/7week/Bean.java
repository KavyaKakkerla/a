
/*ArithmeticException, NullPointerExceptions, ArrayIndexOutOfBoundsException,
IOException*/
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
public class Bean
{
	public static void main(String args[])
	{
	    try{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter new String ");
		String nullString=null;
			int length=nullString.length();
		String s=sc.next();
		System.out.println("Enter two numbers");
		System.out.println("Quotient is "+(double)(sc.nextInt()/sc.nextInt()));
		int a[]={1,2,3};
		System.out.println("Enetr the index");
		int index;
		index=sc.nextInt();
		System.out.println("index"+a[index]);
		FileReader f=new FileReader("file.txt");
		f.close();
		sc.close();
	    }
	catch(ArithmeticException e)
	{
		System.out.println("aryhemetic exception");
	}
	catch(NullPointerException e)
	{
		System.out.println("null pointer exception");
	}
	catch(IndexOutOfBoundsException e)
	{
		System.out.println("Array index out oof bund exception");
	}
	catch(FileNotFoundException e)
	{
		System.out.println("file not found exception");
	}
	catch(IOException e)
	{
		System.out.println("io exception");
	}
	catch(Exception e)
	{	
		System.out.println("exception");
	}
}
}
