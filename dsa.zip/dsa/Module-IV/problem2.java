
class Person{
	public String name,address;
	public Person(){
		
	}
	public Person(String name,String address){
		this.name = name;
		this.address = address;
	}
	public String getName(){
		return this.name;
	}
	public String getAddress(){
		return this.address;
	}
	public void setAddress(String address){
		this.address = address;
	}
	public String toString(){
		return this.name+"("+this.address+")";
	}
}

class Student extends Person{
	public int numCourses = 0;
	public String courses[] = new String[30];
	public int grades[] = new int[30];
	static int count = -1;
	public Student(){
		
	}
	public Student(String name,String address){
		super(name,address);
	}
	public void addCourseGrade(String course, int grade){
		if(count==29){
			System.out.println("No more courses can be added");
		}
		else{
			count++;
			//courses[count] = new String();
			courses[count] = course;
			grades[count] = grade;
		}
	}
	public void printGrades(){
		System.out.printf("----------------------------------\n");
		System.out.printf("courses\t\tgrades\n");
		for(int i = 0;i<= count;i++){
			System.out.printf(courses[i]+"\t\t"+grades[i]+"\n");
		}
	}
	public double getAverageGrade(){
		int sum = 0;
		for(int i = 0;i<= count;i++){
			sum+= grades[i];
		}
		return (double)sum/(count+1);
	}
}

class Teacher extends Person{
	public int numCourses = 0;
	public String courses[] = new String[5];
	static int count = -1;
	public Teacher(){
		
	}
	public Teacher(String name,String address){
		super(name,address);
	}
	public boolean addCourse(String course){
		if(count==4){
			System.out.println("No more courses can be added");
			return false;
		}
		else if(count == -1){
			courses[++count] = course;
			return true;
		}
		else if(count<4){
			for(int i = 0;i<=count;i++){
				if(courses[i].equals(course))
					return false;
			}
			courses[++count] = course;
		}
		return true;
	}
	public boolean removeCourse(String course){
		int flag = 0,index = -1;
		for(int i=0;i<=count;i++){
			if(courses[i].equals(course)){
				flag = 1;
				index = i;
			}
		}
		if(flag==0)
			return false;
		for(int j = index;j<count;j++){
			courses[j] = courses[j+1];
		}
		count--;
		return true;
	}
	public void PrintCourses(){
		System.out.println("-----courses------");
		for(int i=0;i<=count;i++){
			System.out.println(courses[i]);
		}
	}
	
}



public class problem2{
	public static void main(String args[]){
		Person p = new Person("Ravi","jangoan");
		System.out.println("name of Person: "+p.getName());
		System.out.println("address of Person: "+p.getAddress());
		//student
		Student s = new Student("Pranav","Godavari kani");
		System.out.println(s.toString());
		s.addCourseGrade("Java",4);
		s.addCourseGrade("Python",5);
		s.addCourseGrade("DBMS",4);
		s.printGrades();
		System.out.printf("Average grade is: %.2f\n",s.getAverageGrade());
		//teacher
		Teacher t = new Teacher("Manjula","JammuKashmir");
		System.out.println(t.toString());
		System.out.println(t.addCourse("DBMS"));
		System.out.println(t.addCourse("Java"));
		System.out.println(t.removeCourse("Java"));
		t.PrintCourses();
	}
}