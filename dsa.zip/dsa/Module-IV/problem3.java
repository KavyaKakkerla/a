
interface Monster{
	public String name=null;
	public String attack();
}

class FireMonster implements Monster{
	public String attack(){
		return " Fire attack ";
	}
}

class WaterMonster implements Monster{
	public String attack(){
		return " Water attack ";
	}
}

class StoneMonster implements Monster{
	public String attack(){
		return " Stone attack ";
	}
}


public class problem3{
	public static void main(String args[]){
		Monster f = new FireMonster();	//upcasting
		Monster w = new WaterMonster();
		Monster s = new StoneMonster();
		System.out.println(f.attack());
		System.out.println(w.attack());
		System.out.println(s.attack());
	}
}