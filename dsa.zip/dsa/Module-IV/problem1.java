import java.util.*;
//overRiding
abstract class Shape{
	abstract public double getArea();
	abstract public double getPerimeter();
}

class Square extends Shape{
	public double side;
	public double getArea(){
		return side*side;
	}
	public double getPerimeter(){
		return 4*side;
	}
}

class Circle extends Shape{
	public double radius;
	public double getArea(){
		return Math.PI*radius*radius;
	}
	public double getPerimeter(){
		return 2*Math.PI*radius;
	}
}

class Rectangle extends Shape{
	public double length,breadth;
	public double getArea(){
		return length*breadth;
	}
	public double getPerimeter(){
		return 2*(length+breadth);
	}
}

public class problem1{
	public static void main(String args[]){
		Square S = new Square();
		Circle C = new Circle();
		Rectangle R = new Rectangle();
		Scanner sc = new Scanner(System.in);
		System.out.print("Side of Square: ");
		S.side = sc.nextDouble();
		System.out.print("Radius of Circle: ");
		C.radius = sc.nextDouble();
		System.out.print("Length of rectangle: ");
		R.length = sc.nextDouble();
		System.out.print("Breadth of rectangle: ");
		R.breadth = sc.nextDouble();
		System.out.println("Area of Square: "+S.getArea());
		System.out.println("Perimeter of Square: "+S.getPerimeter());
		System.out.println("Area of rectangle: "+R.getArea());
		System.out.println("Perimeter of rectangle: "+R.getPerimeter());
		System.out.println("Area of circle: "+C.getArea());
		System.out.println("Perimeter of Circle: "+C.getPerimeter());
		sc.close();
	}
}