import java.util.*;

class discount{
	public double hdfc(){
		return 0.1;
	}
	public double abv5(){
		return 0.15;
	} 
	public double rgukt(){
		return 0.3;
	}
	public double abv3(){
		return 0.5;
	}
}

class product{
	public String name,company;
	public double price;
	public product(String name,String compamy,double price){
		this.name = name;
		this.company = compamy;
		this.price = price;
	}
	public String toString(){
		return this.name+" "+this.company+" "+this.price;
	}
}

public class problem6{
	public static void main(String args[]){
		product p[] = new product[5];
		p[0] = new product("Umbrella","TukTuk",350);
		p[1] = new product("Shoes","Bata",500);
		p[2] = new product("Laptop","dell",150000);
		p[3] = new product("Phone","Iqoo",34000);
		p[4] = new product("Pods","Oneplus",2800);
		System.out.println("Product name-company-price");
		for(int i = 0;i<5;i++){
			System.out.println(p[i]);
		}
		System.out.println("Enter product name: ");
		Scanner sc = new Scanner(System.in);
		String n = sc.next(),s;
		System.out.println("Enter product quantity: ");
		double q = sc.nextInt();
		for(int i=0;i<5;i++){
			s = p[i].name;
			if(s.equals(n)){
				q = q*p[i].price;
			}
		}
		discount d = new discount();
		double d1=0,d2=0;
		System.out.println("Do you posses HDFC card[1-yes,0-no]: ");
		if(sc.nextInt() == 1)
			d1 = d.hdfc();
		System.out.println("are you from rgukt?[1-yes,0-no] ");
		if(sc.nextInt() == 1)
			d2 = d.rgukt();
		if(q>30000){
			d2 += d.abv3();
		}
		if(q>50000){
			d1 += d.abv5();
		}
		if(d1*q>d2*q){
			System.out.println("Amazon");
		}
		else
			System.out.println("Flipkart");
		sc.close();
	}
}