import java.util.*;

interface Bank{
    boolean credentialsCheck(String username,String password) throws Exception;
    void credit(double a);
    void debit(double a) throws Exception;
    void displayBalance();
    void exit();
}

class SBI implements Bank{
    private String username,password;
    double balance;
    SBI(String u, String p){
        this.password = p;
        this.username = u;
    }
    String getUsername(){
        return username;
    }
    String getPassword(){
        return password;
    }
    public String toString(){
        return username;
    }
    public boolean credentialsCheck(String username,String password) throws Exception{
        if(this.username.equals(username) && this.password.equals(password)){
        return true;
        }
        else{
            throw new Exception();
        }
    }
    public void credit(double a){
        this.balance+=a;
    }
    public void debit(double a) throws Exception{
        if(this.balance<a){
            throw new Exception();
        }
        else{
            this.balance-=a;
        }
    }
    public void displayBalance(){
        System.out.println("Current balance is "+this.balance);
    }
    public void exit(){
        System.exit(10);
    }
}


public class p4 {
    public static void main(String[] args) {
        System.out.println("***********Welcome to Bank*************");
        System.out.print("Enter no of users in a bank: ");
        Scanner sc = new Scanner(System.in);
        int nou = sc.nextInt();
        SBI[] u = new SBI[nou];
        for(int i=0;i<nou;i++){
            System.out.print("Enter username("+(i+1)+"): ");
            String un = sc.next();
            System.out.print("Enter Password: ");
            u[i] = new SBI(un,sc.next());
        }
        System.out.println("--------------Welcome----------------");
        while(true){
            System.out.println("Enter 1 to make transaction 0 to exit");
            int ch1 = sc.nextInt();
            if(ch1==0){
                sc.close();
                System.exit(0);
            }
            System.out.println("-----Enter your details-----");
            System.out.print("Username: ");
            String s1 = sc.next();
            int f =0;
            for(int i=0;i<nou;i++){
                if(s1.equals(u[i].getUsername())){
                    f = 1;
                    System.out.print("Enter password: ");
                    boolean b=false;
                    try{
                    b = u[i].credentialsCheck(s1,sc.next() );
                    }
                    catch(Exception e){
                        System.out.println("Wrong Credentials");
                    }
                    //sc.close();
                    if(b==true){
                        while(true){
                        System.out.print("1)Credit\n2)Debit\n3)Display Balance\n4)Exit\nChoose: ");
                        int ch2 = sc.nextInt();
                        if(ch2==1){
                            System.out.println("Enter amount to credit: ");
                            u[i].credit(sc.nextDouble());
                        }
                        else if(ch2==2){
                            System.out.println("Enter amount to debit: ");
                            try{
                            u[i].debit(sc.nextDouble());
                            }
                            catch(Exception e){
                                System.out.println("Insufficient balance");
                            }
                        }
                        else if(ch2==3){
                            u[i].displayBalance();
                        }
                        else{
                            u[i].exit();
                        }
                        }
                    }
                }
            }
            if(f==0){
                System.out.println("User Not Found");
            }
        }
    }
}