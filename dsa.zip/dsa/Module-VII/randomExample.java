import java.util.Random;
public class randomExample {
    public static void main(String[] args) {
        Random rd = new Random();
        System.out.println(rd.nextInt(3));
    }
}
