public class p2 {
    public static void main(String[] args) {
        String s = "123a";
        try{
            int a = Integer.valueOf(s);
            System.out.println(a);
        }
        catch(NumberFormatException e){
            System.out.println(e);
        }
    }
}
