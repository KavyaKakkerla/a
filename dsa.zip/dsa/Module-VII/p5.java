import java.util.*;

interface TaxInterface{
    boolean taxChecker() throws Exception;
    double taxPaid();
    double homeExpenditure();
    double healthExpenditure();
    double VehicleExpenditure();
    double personalFamilyExpenditure();

}

class Person implements TaxInterface{
    double tp,he,hee,ve,pfe,in,payable,e,me;
    String name;
    Scanner sc = new Scanner(System.in);
    Person(String name,double in){
        this.name = name;
        this.in = in;
    }
    public boolean taxChecker() throws Exception{
        e = homeExpenditure()+VehicleExpenditure()+healthExpenditure()+personalFamilyExpenditure()+miscellaneousExpenditure();
        tp = taxPaid();
        payable = (this.in -e)*0.1;
        if(tp<payable){
            throw new Exception("You have not piad tax");
        }
        return true;
    }
    public double taxPaid(){
        System.out.println("Tax paid: ");
        tp= sc.nextDouble();
        return tp;
    }
    public double homeExpenditure(){
        System.out.print("House: ");
        he = sc.nextDouble();
        return he;
    }
    public double healthExpenditure(){
        System.out.println("Health: ");
        hee = sc.nextDouble();
        return hee;
    }
    public double VehicleExpenditure(){
        System.out.println("vehicle: ");
        ve = sc.nextDouble();
        return ve;
    }
    public double personalFamilyExpenditure(){
        System.out.println("Personal family: ");
        pfe = sc.nextDouble();
        return pfe;
    }
    public double miscellaneousExpenditure(){
        System.out.println("Miscellaneous: ");
        me = sc.nextDouble();
        return me;
    }
}
public class p5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name;
        double in;
        System.out.println("-------------welcome to Tax fraud Detector-------------");
        System.out.println("Enter your details  below");
        System.out.print("Name: ");
        name = sc.next();
        System.out.print("Income: ");
        in = sc.nextDouble();
        System.out.println("Enter expenditures od respective fields");
        Person p = new Person(name,in);
        boolean b = false;
        try{
        b = p.taxChecker();
        }
        catch(Exception e){
            System.out.println(e);
            System.out.println("Payable amount: "+(p.payable-p.tp));
        }
        if(b==true)
        System.out.println("Tax paid");
        sc.close();
    }
}
