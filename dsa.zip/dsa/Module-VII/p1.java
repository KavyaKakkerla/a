class Super{
    Super(String s){
        
    }
    public void meth1() throws Exception{
        System.out.println(10/0);
    }
}

public class p1{
    public static void main(String[] args) {
        int a = 10,b = 0;
        try{
            int c = a/b;
            System.out.println("Result of division: "+c);
        }
        catch(ArithmeticException e){
            System.out.println(e);
        }
        finally{
            System.out.println("Am done");
        }
        Super s = new Super("Surya");
        try{
            s.meth1();
        }
        catch(Exception e){
            System.out.println(e);
        }

    }
}