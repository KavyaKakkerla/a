import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class p6 {
    public static void main(String[] args) {
        try{
           
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter a string: ");
            String s = sc.next();
            System.out.println("Enter two elements: ");
            System.out.println("Quotient: "+(double)(sc.nextInt()/sc.nextInt())); //Arithmetic
            int a[] = {1,2,3};
            System.out.print("Enter a index to access element: ");
            int in = sc.nextInt();
            System.out.println("Element: "+a[in]); //IndexOutOfBound 
            System.out.println(s.charAt(7)); //IndexOutofBound
            FileReader f = new FileReader("file.txt"); // FilenotFounde
            f.close();  //IO Exception          
            sc.close();
        }
        catch(ArithmeticException e){
            System.out.println(e.getMessage());
        }
        catch(NullPointerException e){
            System.out.println(e.getMessage());
        }
        catch(IndexOutOfBoundsException e){
            System.out.println(e.getMessage());
        }
        catch(FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
}