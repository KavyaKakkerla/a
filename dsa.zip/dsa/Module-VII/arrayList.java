import java.util.*;
public class arrayList {
    public static void main(String[] args) {
        List<Integer> l = new ArrayList<Integer>();
        l.add(2);
        System.out.println(l.size());
    }
}
