import java.util.*;

class Book{
    String Book_title,Book_Author,Branch_name;
    int Book_isbn,Book_count;
    Book(){}
    Book(String bt,String ba,int bi,int q,String b){
        this.Book_Author = ba;
        this.Book_title = bt;
        this.Branch_name = b;
        this.Book_count = q;
        this.Book_isbn = bi;
    }
    public String toString(){
        return this.Book_count+"\t\t"+Book_title;
    }
    public void display_catalog(List<Book> b){
        System.out.println("**************Books*******************\nCount\t\tTitle");
        for(int i=0;i<b.size();i++){
            System.out.println(b.get(i));
        }
    }
}

class Student{
    int Student_id;
    int flag = 0;
    List<String> studentBooks = new ArrayList<String>();
    String Student_name,Student_username,Student_password;
    Student(int si,String sn,String su,String sp){
        this.Student_id = si;
        this.Student_name = sn;
        this.Student_password = sp;
        this.Student_username = su;
    }
    public boolean checkCredentials(String pw){
        if(this.Student_password.equals(pw))
        return true;
        else
        return false;
    }
}


public class LMS{
    public static void main(String[] args) {
        System.out.println("**********************Books Catalog********************");
        System.out.print("Enter no of branches: ");
        Scanner sc = new Scanner(System.in);
        int nob = sc.nextInt();
        String branches[] = new String[nob];
        int tobo = 0; //total books
        List<Book> books = new ArrayList<Book>();
        for(int i=0;i<nob;i++){
            System.out.printf("Enter branch name(%d): ",i+1);
            branches[i] = sc.next();
            System.out.print("no of types books this branch: ");
            int nobo  = sc.nextInt();
            tobo+=nobo;
            System.out.println("Enter books details below");
            for(int j=0;j<nobo;j++){
                System.out.printf("Book(%d)",j+1);
                System.out.print("\nTitle: ");
                String bt = sc.next();
                System.out.print("Author: ");
                String ba = sc.next();
                System.out.print("ISBN: ");
                int bi = sc.nextInt();
                System.out.print("Quantity of these books: ");
                int q = sc.nextInt();
                Book B = new Book(bt,ba,bi,q,branches[i]);
                books.add(B);
            }
        }
        System.out.println("Enter no of Students: ");
        int nos = sc.nextInt();
        Student[] s = new Student[nos];
        System.out.println("Enter details of students: ");
        for(int i=0;i<nos;i++){
            System.out.println("User"+(i+1));
            System.out.printf("Name: ");
            String sn = sc.next();
            System.out.printf("Username ");
            String su = sc.next();
            System.out.printf("password: ");
            String sp = sc.next();
            System.out.printf("id: ");
            int si = sc.nextInt();
            s[i] = new Student(si,sn,su,sp);
        }
        while(true){
            System.out.println("****************welcome***********************");
            System.out.print("\n\t1)Login\n\t2)Exit\nChoose: ");
            int h = sc.nextInt();
            if(h==1){
                System.out.print("Username: ");
                String un = sc.next();
                System.out.print("Password: ");
                String pw = sc.next();
                boolean b = false;
                int index = -1;
                try{
                for(int i=0;i<nos;i++){
                    if(un.equals(s[i].Student_username)){
                        b = s[i].checkCredentials(pw);
                        if(b==true){
                            index = i;
                            break;
                        }
                    }
                }
                if(b!=true)
                throw new Exception("***********Exception: Credentials Mismatch*****************");
                }
                catch(Exception e){
                    System.out.println(e);
                }
                while(b==true){
                    System.out.print("\n\t1)Borrow\n\t2)Return\n\t3)Exit(logout)\nChoose: ");
                    int h1 = sc.nextInt();
                    if(h1==1){
                        try{
                            if(s[index].studentBooks.size()==3)
                            throw new Exception("***************Exception: Books borrowedExceededinNumber******************");
                        }
                        catch(Exception e){
                            System.out.println(e);
                            break;
                        }
                        new Book().display_catalog(books);
                        System.out.print("Enter a Book title: ");
                        String bT = sc.next();
                        try{
                        for(int i=0;i<tobo;i++){
                            if(bT.equals(books.get(i).Book_title) && books.get(i).Book_count>0){
                                for(String x:s[index].studentBooks){
                                    if(x.equals(bT))
                                    throw new Exception("************Exception: ONly one copy of a book can be borrowed***************");
                                }
                                books.get(i).Book_count--;
                                s[index].studentBooks.add(bT);
                                System.out.println("Book Successfully Borrowed");
                                break;
                            }
                        }
                        new Book().display_catalog(books);
                        }
                        catch(Exception e){
                            System.out.println(e);
                        }
                    }
                    else if(h1==2){
                        if(s[index].studentBooks.size()==0){
                            System.out.println("no books to return");
                            continue;
                        }
                        System.out.print("Books you can return");
                        for(String x:s[index].studentBooks){
                            System.out.println(x);
                        }
                        System.out.println("Enter a book title to return: ");
                        String btt = sc.next();
                        int flag = 0;
                        for(int i=0;i<tobo;i++){
                            if(books.get(i).Book_title.equals(btt)){
                                flag = 1;
                                books.get(i).Book_count++;
                            }
                        }
                        if(flag==1){
                        s[index].studentBooks.remove(btt);
                        System.out.println("Book Succesfully returned");
                        }
                        else{
                            System.out.println("No such book to return");
                        }
                    }
                    else if(h1==3){
                        break;
                    }
                    else{
                        System.out.println("Invalid option");
                    }
                }
            }
            else if(h==2){
                sc.close();
                System.exit(0);
            }
            else{
                System.out.println("INVALID CHOICE");
            }
        }
    }
}