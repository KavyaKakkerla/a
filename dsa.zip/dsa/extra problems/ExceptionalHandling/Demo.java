public class Demo {
    public static void main(String[] args) {
        int a = 10,b=0,c;
        try{
            c = a/b;
            System.out.println(c);
        }
        catch(ArithmeticException e){
            System.out.println("Denominator can't be zero "+e);
        }
       // finally{
        System.out.println("BYE");
       // }
    }
}
