//package ExceptionalHandling;
import java.io.*;
public class finenotFound {
    static void fun1(){
        try{
            FileInputStream f = new FileInputStream("MY.txt");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            System.out.println(e);
            e.printStackTrace();
        }
    }
    static void fun2(){
        fun1();
    }
    static void fun3(){
        fun2();
    }
    public static void main(String[] args) {
        fun3();
    }
}
