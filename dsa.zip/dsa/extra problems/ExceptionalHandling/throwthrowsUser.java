//package ExceptionalHandling;
class NegativeDimensionException extends Exception{
    public String toString(){
        return "Dimension can't be negative";
    }
}
public class throwthrowsUser {
    static int area(int l,int b) throws NegativeDimensionException{
        if(l<0 || b<0)
        throw new NegativeDimensionException();
        return l*b;
    }
    static void meth2() throws Exception{
        System.out.println(area(-10,5));
    }
    public static void main(String[] args) {
        try{meth2();}
        catch(NegativeDimensionException e){System.out.println(e);}
    }
}
