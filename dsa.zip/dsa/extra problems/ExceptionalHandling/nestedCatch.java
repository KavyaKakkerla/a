//package ExceptionalHandling;

public class nestedCatch {
    public static void main(String[] args) {
        int a[] = {30,20,10,40,0};
        try{
            int c = a[0]/a[2];
            System.out.println("Division is: "+c);
            System.out.println(a[10]);
        }
        catch(ArithmeticException e){
            System.out.println("Denominator cannot be 0");
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Index is invalid");
        }
        System.out.println("Bye");
    }
}
