//package ExceptionalHandling;

public class throwthrows2 {
    static int area(int l,int b) throws Exception{
        if(l<0 || b<0)
        throw new Exception();
        return l*b;
    }
    static void meth2() throws Exception{
        System.out.println(area(-10,5));
    }
    public static void main(String[] args) {
        try{meth2();}
        catch(Exception e){System.out.println(e);}
    }
}
