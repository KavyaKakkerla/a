import java.util.*;

class book{
    String Book_title,isbn_no,book_author;
    int book_count;
    public book(String t,int c){
        this.Book_title = t;
        this.book_count = c;
    }
}

class customer{
    String user_name,password,customer_id,customer_name,customer_address;
    List<String> titles = new ArrayList<String>();
    int count_bought=0;
    public customer(String n,String un,String p){
        this.user_name = un;
        this.customer_name = n;
        this.password = p;
    }
    public book search(String title,List<book> l){
        for(book b:l){
            if(b.Book_title.equals(title) && b.book_count >0)
            return b;
        }
        return null;
    }
    public int buy(String title,List<book> l){
        book flag = search(title,l);
        if(flag!=null){
            flag.book_count --;
            titles.add(flag.Book_title);
            this.count_bought++;
            System.out.println("\t\t\tPurchase Successfull");
            return 1;
        }
        System.out.println("\t\t\tOOPs Purchase UnSuccessfull");
        return 0;
    }
    public void display(List<customer> cl){
        System.out.println("**********************Customer Details**********************");
        for(customer s:cl){
            System.out.println(s.customer_name);
            System.out.println("BOOKs bought:");
            for(String d:s.titles){
                System.out.print(d+",");
            }
            System.out.println("\nTotal books bought: "+s.count_bought);
        }
    }
}


class q1{
    public static void main(String[] args) {
        List<book> l = new ArrayList<book>();
        List<customer> cl = new ArrayList<customer>();
        List<customer> users = new ArrayList<customer>();
        System.out.println("**********************Enter owner details**********************");
        Scanner sc = new Scanner(System.in);
        System.out.print("\tUsername: ");
        String own = sc.next();
        System.out.print("\tPassword: ");
        String ownp = sc.next();
        customer owner = new customer("Owner",own,ownp);
        System.out.print("\nEnter no of customers: ");
        int noc = sc.nextInt();
        
        System.out.println("**********************Enter customer details**********************");
        for(int i=0;i<noc;i++){
            System.out.print("\nEnter customer name: ");
            String n = sc.next();
            System.out.print("Enter customer username: ");
            String un = sc.next();
            System.out.print("Enter password: ");
            String pa = sc.next();
            customer m = new customer(n,un,pa);
            users.add(m);
        }
        System.out.print("Enter no of Books: ");
        int nob = sc.nextInt();
        System.out.println("**********************Enter BOOK details**********************");
        for(int i=0;i<nob;i++){
            System.out.print("\nEnter book title: ");
            String t = sc.next();
            System.out.print("Enter book count: ");
            int c = sc.nextInt();
            book b = new book(t,c);
            l.add(b);
        }
        System.out.println("***********Data Succesfully Inserted*******************");
        while(true){
            System.out.print("\n\n\t\t1.Login\n\t\t2.Exit\nChoose: ");
            int ch = sc.nextInt();
            if(ch==2){
            sc.close();
            System.exit(1);
            }
            System.out.print("Enter Username: ");
            String user = sc.next();
            System.out.print("Password: ");
            String pass = sc.next();
            if(user.equals(own) && pass.equals(ownp)){
                while(true){
                System.out.print("\n\t\t1)Display\t\t2)Logout\nChoose: ");
                int ch2 = sc.nextInt();
                if(ch2==2)
                break;
                owner.display(cl);
                }
                continue;
            }
            customer flag = null;
            for(customer x:users){
                if(x.user_name.equals(user) && x.password.equals(pass))
                flag = x;
            }
            if(flag==null){
                System.out.println("*****************User not Found******************");
                continue;
            }
            while(true){
            System.out.print("\n\t\t1)Search\t\t2)Buy\t\t3)Logout\nChoose: ");
            int ch2 = sc.nextInt();
            if(ch2==3){
                System.out.print("\tConfirm Logout\n\t1.Yes\n\t2.No\nchoose: ");
                int ch3 = sc.nextInt();
                if(ch3==1)
                break;
                continue;
            }
            System.out.print("\n\tEnter Book Title: ");
            String titl = sc.next();
            if(ch2==1){
                book b = flag.search(titl,l);
                if(b==null){
                    System.out.println("*************Book Not Found****************");
                }
                else{
                    System.out.println("************Book Found************");
                }
            }
            else if(ch2==2){
                int i = flag.buy(titl,l);
                if(i==1)
                cl.add(flag);
            }
            }
        }
    }
}