void main()
{ 
  //declaration
  printf("Wel come");
  //End
}
