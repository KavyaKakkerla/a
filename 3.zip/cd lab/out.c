void main()
{ 
  
  printf("Wel come");
  
}
