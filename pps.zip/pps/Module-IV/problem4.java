2import java.util.*;

class Vehicle{
	public String Company,Model;
	public double Mileage;//fuelCapacity,displacement;
	public Vehicle(){}
	public Vehicle(String x,String y,double z){
		this.Company = x;
		this.Model = y;
		this.Mileage = z;
	}
	public String toString(){
		return "Company: "+this.Company+" MOdel: "+this.Model+" Mileage: "+this.Mileage;
	}
}

class Twheeler extends Vehicle{
	public boolean FrontBreak; //rearBreak;
	//public String tireType,headLamp,UserReviews;
	public Twheeler(String x,String y,double z,boolean m){
		super(x,y,z);
		this.FrontBreak = m;
	}
	public Twheeler(){}
	public String toString(){
		return super.toString()+" FrontBreak: "+this.FrontBreak;
	}
}

class Fwheeler extends Vehicle{
	public boolean airConditioner;//airbags,powerSteering,RainSensingWiper;
	public Fwheeler(String x,String y,double z,boolean m){
		super(x,y,z);
		this.airConditioner = m;
	}
	public Fwheeler(){}
	public String toString(){
		return super.toString()+" airConditioner: "+this.airConditioner;
	}
}

public class problem4{
	public static void main(String args[]){
		Twheeler tw[] = new Twheeler[4];
		Fwheeler fw[] = new Fwheeler[4];
		Scanner sc = new Scanner(System.in);
		tw[0] = new Twheeler("Honda","CS200",67.3,true);
		tw[1] = new Twheeler("Honda","Livo",63.5,true);
		tw[2] = new Twheeler("Honda","CS200",47.5,false);
		tw[3] = new Twheeler("Honda","CS200",39.9,true);
		
		fw[0] = new Fwheeler("Maruti Suzuki","Swift",167.3,true);
		fw[1] = new Fwheeler("Maruti Suzuki","Wagon R",180.3,true);
		fw[2] = new Fwheeler("Mercedes","Benz",200.3,true);
		fw[3] = new Fwheeler("Hyundai","Creta",186.4,true);
		System.out.println("-----------Two Wheelers----------------");
		for(int i = 0;i<4;i++){
			System.out.println(tw[i]);
		}
		System.out.println("-----------Four Wheelers----------------");
		for(int i = 0;i<4;i++){
			System.out.println(fw[i]);
		}
		System.out.println("Which vehicle do you want to compare{2|4}: ");
		int choice = sc.nextInt();
		if(choice == 2){
			Twheeler r = new Twheeler();
			double max=0;
			for(int i =0;i<4;i++){
				if(tw[i].Mileage >max){
					max = tw[i].Mileage ;
					r = tw[i];
				}
			}
			System.out.println(r);
		}
		else if(choice == 4){
			Fwheeler r = new Fwheeler();
			double max=0;
			for(int i =0;i<4;i++){
				if(fw[i].Mileage >max){
					max = fw[i].Mileage ;
					r = fw[i];
				}
			}
			System.out.println(r);
		}
		else{
			System.out.println("choose right option");
		}
		sc.close();
	}
}
