import TV_REMOTE.Tv;
import TV_REMOTE.operation;
import java.util.*;
public class Remote{
  public static void main(String[] args){
   Scanner sc= new Scanner(System.in);
   operation p= new operation();
  // Tv t= new Tv();
   while(true){
   System.out.println("\nENter the choice in the Remote\n");
   System.out.println("1 ---> Switch_ON");
      System.out.println("2---> STAR MOVIES");
         System.out.println("3 --->NGC chaneel ");
            System.out.println("4 ---> Discovery");
               System.out.println("5 ---> STAR SPORTS");
                  System.out.println("6 ---> Switch_OFF");
                  System.out.println("0 --> exit");
                  
                  int ch=sc.nextInt();
                  switch(ch){
                   case 1:
                      p.Switch_on();
                      break;
                         
                  case 2:
                      p.StarMovies();
                      break;
                 case 3:
                      p.NGC();
                      break;
                  case 4:
                      p.Discovery();
                      break; 
                      
                  case 5:
                      p.StarSports();
                      break; 
                    
                  case 6:
                      p.Switch_off();
                      break;
                  case 0:
                      System.out.println("Exiting from the programm");
                      System.exit(0);
                      break; 
                  default:
                    System.out.println("enetr the correct choice which are on remote only");
              
                  }
                  
   }
}
}

