package TV_REMOTE;
public interface Tv{
 void Switch_on();
 void Switch_off();
 void StarMovies();
 void NGC();
 void Discovery();
 void StarSports();
  
}

