package TV_REMOTE;

public class operation implements Tv {

    private boolean on;
  

    public operation() {
        this.on = false;
     
    }

    public void Switch_on() {
        System.out.println("Welcome to TATA SKY");
        this.on = true;
    }

    public void Switch_off() {
        System.out.println("TV turned off");
        this.on = false;
      
    }

    public void StarMovies() {
        displayChannel("STAR MOVIES CHANNEL");
    }

    public void NGC() {
        displayChannel("NGC CHANNEL");
    }

    public void Discovery() {
        displayChannel("Discovery CHANNEL");
    }

    public void StarSports() {
        displayChannel("STAR SPORTS CHANNEL");
    }

    private void displayChannel(String channelName) {
    
          String sk=channelName;
       
    if (this.on) {
    System.out.println("You are watching your desired " + sk + " && enjoy it");
           
        } else {
            System.out.println("TV is not switched on");
        }
    }

    
}

