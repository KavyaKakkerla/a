import java.util.Random;
import java.util.Scanner;

public class TTB {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random r = new Random();

        System.out.println("Welcome to Train Ticket Booking System!");
        System.out.println("We have two AC coaches (B1, B2) and two Sleeper coaches (S1, S2).");

        String input = "";
        while (!input.equalsIgnoreCase("exit")) {
            try {
                System.out.print("Enter the number of berths you want to book (not more than 6): ");
                int n = sc.nextInt();
               sc.nextLine(); // Consume the newline character

                System.out.print("Enter the class (AC or Sleeper): ");
                String CC = sc.nextLine();

                if ( n > 6 || n <= 0 || (!CC.equalsIgnoreCase("ac") && !CC.equalsIgnoreCase("sleeper"))) {
                    throw new Exception("You may be an Agent. Booking denied.");
                }

                System.out.println("Your confirmed berth(s) are:");

                for (int i = 0; i < n; i++) {
                    String coach = (CC.equalsIgnoreCase("ac")) ? "B" : "S";
                    int coachNum = r.nextInt(2) + 1;
                    int seatNum = r.nextInt(70) + 1;
                    System.out.println(coach + coachNum + " " + seatNum);
                }

                System.out.print("Enter 'exit' to exit or press Enter to book more tickets: ");
                input = sc.nextLine();

            } catch (Exception e) {
                System.out.println("Booking failed: " + e.getMessage());
                System.out.print("Enter 'exit' to exit or press Enter to try again: ");
                input = sc.nextLine();
            }
        }

        System.out.println("Thank you for using the Train Ticket Booking System!");
      
    }
}

