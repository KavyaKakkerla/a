#include<stdio.h>
#include<stdlib.h>
int find(int ref[],int n,int head,int visited[])
{
    int mindis=9999;
    int index;
    for(int i=0;i<n;i++)
    {
        
        if(visited[i]==-1)
       { int dis=abs(head-ref[i]);
        if(mindis>dis)
        {
            mindis=dis;
            index=i;
        }
       }
    }
    visited[index]=0;
    return index;
}
void sstf(int ref[],int n,int head,int visited[])
{
   printf("%d ",head);
    int totaldistance=0;
    for(int i=0;i<n;i++)
    {
        int min=find(ref,n,head,visited);
        totaldistance+=abs(head-ref[min]);
        
        head=ref[min];
        printf("%d ",head);


        

    }
    printf("\ntotal distance is %d :",totaldistance);
}

int main()
{
    int n;
    printf("Enetr the total number :");
    scanf("%d",&n);
    int ref[n];
    int visited[n];
    printf("\nEnetr the referenece string :");
    for(int i=0;i<n;i++)
    {
        scanf("%d",&ref[i]);
        visited[i]=-1;
    }
    printf("\nenter the head starting position");
    int head;
    scanf("%d",&head);
    sstf(ref,n,head,visited);
}