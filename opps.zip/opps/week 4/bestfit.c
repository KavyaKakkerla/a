#include<stdio.h>


int main()
{
	int np,nb;
	printf("enter the no of processors\n");
	scanf("%d",&np);
	printf("Enter the no of blocks\n ");
	scanf("%d",&nb);
	printf("enter the block size\n");
	int b[nb];
	int a[np],inf[np];
	int ab[nb];
	
	for(int i=0;i<nb;i++)
	{
		scanf("%d",&b[i]);
		ab[i]=-1;
	}
	printf("ENter the processors size \n");
	int p[np];
	for(int i=0;i<np;i++)
	{
		scanf("%d",&p[i]);
		a[i]=-1;
		inf[i]=0;
	}
	int k=0,s=0;
	
	for(int i=0;i<np;i++)
	{
		int bestfitblock=-1;
		for(int j=0;j<nb;j++)
		{
			if(b[j]>=p[i]&&ab[j]==-1)
			{
				if(bestfitblock==-1 || b[j]<b[bestfitblock])
				{
					bestfitblock=j;
				}
			}
		}
		if(bestfitblock!=-1)
		{
			a[i]=bestfitblock;
			inf[i]=b[bestfitblock]-p[i];
			b[bestfitblock]=b[bestfitblock]-p[i];
			ab[bestfitblock]=1;
				
		}
		
		k+=inf[i];
	}
	for(int i=0;i<nb;i++)
	{
		if(ab[i]==-1)
		{
			s+=b[i];
		}
	}
	//printf("\nResult");
	printf("process no\tproces size\talloated block  internal fragmentaion\n");
	
	for(int i=0;i<np;i++)
	{
		
		printf("%d\t\t%d\t",i+1,p[i]);
		if(a[i]!=-1)
		{
			printf("\t%d\t\t%d\n",a[i]+1,inf[i]);
		}
		else
		{
			printf("not alloated\n");
		}
	}
	printf("\nThe internal fragmentaion is %d",k);
	printf("\nThe external fragmentation is %d",s);
	}
