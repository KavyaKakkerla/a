import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Vehicle {
    private String company;
    private String model;
    private int mileage;
    private int fuelCapacity;
    private int displacement;

    public Vehicle(String company, String model, int mileage, int fuelCapacity, int displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuelCapacity = fuelCapacity;
        this.displacement = displacement;
    }

    public String getCompany() {
        return company;
    }

    public String getModel() {
        return model;
    }

    public int getMileage() {
        return mileage;
    }

    public int getFuelCapacity() {
        return fuelCapacity;
    }

    public int getDisplacement() {
        return displacement;
    }
}

class TwoWheeler extends Vehicle {
    private String frontBrake;
    private String rearBrake;
    private String tyreType;
    private String headLamp;
    private String userReviews;

    public TwoWheeler(String company, String model, int mileage, int fuelCapacity, int displacement, String frontBrake, String rearBrake, String tyreType, String headLamp, String userReviews) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.frontBrake = frontBrake;
        this.rearBrake = rearBrake;
        this.tyreType = tyreType;
        this.headLamp = headLamp;
        this.userReviews = userReviews;
    }

    public String getFrontBrake() {
        return frontBrake;
    }

    public String getRearBrake() {
        return rearBrake;
    }

    public String getTyreType() {
        return tyreType;
    }

    public String getHeadLamp() {
        return headLamp;
    }

    public String getUserReviews() {
        return userReviews;
    }
}

class FourWheeler extends Vehicle {
    private String airConditioner;
    private String airBags;
    private String powerSteering;
    private String rainSensingWiper;

    public FourWheeler(String company, String model, int mileage, int fuelCapacity, int displacement, String airConditioner, String airBags, String powerSteering, String rainSensingWiper) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.airConditioner = airConditioner;
        this.airBags = airBags;
        this.powerSteering = powerSteering;
        this.rainSensingWiper = rainSensingWiper;
    }

    public String getAirConditioner() {
        return airConditioner;
    }

    public String getAirBags() {
        return airBags;
    }

    public String getPowerSteering() {
        return powerSteering;
    }

    public String getRainSensingWiper() {
        return rainSensingWiper;
    }
}

class vehicle {
    TwoWheeler []two=new TwoWheeler[4];
    FourWheeler []four=new FourWheeler[4];
        Scanner sc=new Scanner(System.in);
        two[0]=new TwoWheeler("Honda", "Activa 6G", 60, 5, 109, "Drum", "Drum", "Tubeless", "LED", "4.3");
        two[1]=new TwoWheeler("TVS", "Jupiter", 62, 5, 109, "Drum", "Drum", "Tubeless", "LED", "4.3");
        two[2]=new TwoWheeler("Hero", "Splendor Plus", 80, 9, 97, "Drum", "Drum", "Tubeless", "Halogen", "4.3");
        two[3]=new TwoWheeler("Bajaj", "Pulsar 150", 65, 15, 149, "Disc", "Drum", "Tubeless", "Halogen", "4.3");
        four[0]=new FourWheeler("Maruti Suzuki", "Swift", 23, 37, 1197, "Manual", "2", "Electric", "Yes");
        four[1]=new FourWheeler("Hyundai", "i20", 20, 40, 1197, "Manual", "2", "Electric", "Yes");
        four[2]=new FourWheeler("Kia", "Seltos", 16, 50, 1497, "Manual", "6", "Electric", "Yes");
        four[3]=new FourWheeler("Mahindra","Seltos", 16, 50, 1497, "Manual", "6", "Electric", "Yes");
    

   System.out.println("-----------Two Wheelers----------------");
		for(int i = 0;i<4;i++){
			System.out.println(two[i]);
		}
		System.out.println("-----------Four Wheelers----------------");
		for(int i = 0;i<4;i++){
			System.out.println(four[i]);
		}
        System.out.println("Which vehicle do you want to compare{2|4}: ");
		int choice = sc.nextInt();
		if(choice == 2){
			
            int count;
            System.out.println("ENetr the number of vehicles you want to compare");
            count=sc.nextInt();
            Vehicle v[]=new Vehicle[count];
            for(int i=0;i<count;i++)
            {
                String index;
                System.out.println("Enter the index of the vehicle you want to compare");
                for(int i=0;i<4;i++)
                {
                    if(index.equalsIgnoreCase(two[i].getCompany()))
                    {
                        v[i]=two[i];
                    }
                }
            }
            int max=v[0].getMileage();
            int c=0;
            for(int i=0;i<count;i++)
            {
                
                if(max<v[i].getMileage())
                {
                    max=v[i].getMileage();
                    c=i;
                }
            }
            System.out.println("The best vehicle ");
            System.out.println(v[i]);
		}
		
		}
		
	

