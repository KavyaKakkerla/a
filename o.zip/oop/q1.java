import java.util.Scanner;

public class q1{
    public static void main(String[] args) {
        System.out.println("********Welcome to Movie Theater************");
        int[][] s = new int[4][10];
        int[] avail_seats = new int[4];
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<4;i++)
        avail_seats[i] = 10;
        while(true){
            System.out.print("\n\n\t1.Book Tickets\n\t2.Exit\nchoose: ");
            int choice = sc.nextInt();
            if(choice == 2)
            System.exit(0);
            else if(choice!=1)
            continue;
        int ch = 0;
        System.out.println("Screen 1: Avatar\nScreen 2: Avengers\nScreen 3: Spider Man\nScreen 4: Titanic");
        while(ch<1 || ch>4){
            System.out.println("--------Enter a valid screen---------");
            System.out.print("Choose a Screen[1-4]: ");
            ch = sc.nextInt();
        }
        try{
        if(avail_seats[ch-1]==0)
        throw new Exception();
        }
        catch(Exception e){
            System.out.println("-----Exception: HOUSE FULL------");
            continue;
        }
        System.out.println("Seats Available: ");
        for(int i=0;i<5;i++){
            int status = s[ch-1][i];
            String state = status==1?"B":"NB";
            System.out.print("1_"+(i+1)+"/"+state+" ");
        }
        System.out.println(" ");
        for(int i=5;i<10;i++){
            int status = s[ch-1][i];
            String state = status==1?"B":"NB";
            System.out.print("2_"+(i-4)+"/"+state+" ");
        }
        int nos = 0;
        while(nos<1 || nos>avail_seats[ch-1]){
            System.out.print("\nEnter no of seats you want to Book(within available seats): ");
            nos = sc.nextInt();
        }
        int temp = nos;
        int seats[]= new int[nos],top=0;
        while(nos!=0){
            int row = 0,seat = 0;
            while(row!=1 && row!=2){
                System.out.print("Enter row 1 or 2: ");
                row = sc.nextInt();
            }
            while(seat<1 || seat>5){
                System.out.print("Enter seat [1-5]: ");
                seat = sc.nextInt();
            }
            int se_no = row==1?seat:seat+5;
            if(s[ch-1][se_no-1]==1)
            System.out.println("OOPs that seat is already Booked");
            else{
                System.out.println("Seat "+row+"_"+seat+" Booked");
                seats[top++] = row==1?seat:5+seat;
                s[ch-1][seats[top-1]-1]=1;
                avail_seats[ch-1]--;
                nos--;
            }
        }
        System.out.println("----------MOVIE TICKET------------");
        String title="";
        switch(ch){
            case 1: title += "Avatar";
                break;
            case 2: title += "Avengers";
                break;
            case 3: title += "Spider Man";
                break; 
            case 4: title += "Titanic";
                break;
        }
        System.out.println("Movie\t:\t"+title+"\nScreen :\t"+ch);
        System.out.println("No of Seats :\t"+temp);
        System.out.print("Seat Numbers: ");
        for(int i=0;i<temp;i++){
            if(seats[i]>5)
            System.out.print("2_"+(seats[i]-5)+" ");
            else
            System.out.print("1_"+(seats[i])+" ");
        }
        System.out.println("\nTicket Fair :\t"+temp*300+"/-");
        System.out.println("\t\tEnjoy The Movie\n");
        }
    }
}