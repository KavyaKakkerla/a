interface Fare
{
	double getFare(double distance);
	String getAmenities();
}


class Bus implements Fare
{
	private String busType;
	
	public Bus(String busType)
	{
		this.busType=busType;
	}
	
	public double getFare(double distance)
	{
		double basic=500;
		double add=0.0;
		
		switch(busType.toLowerCase())
		{
			case "ac":
				add+=50;
				break;
			case "sleeper":
				add+=30;
				break;
		}
		return (basic+add)*distance;
	}
	public String getAmenities()
	{
		String aminities="Seat";
		String extra=" ";
		switch(busType.toLowerCase())
		{
			case "ac":
				extra="wifi Ac";
				break;
			case "sleeper":
				extra="wifi";
				break;
		}
		return aminities+extra;
	}
}


class Train implements Fare
{
	private String trainType;
	
	public Train(String trainType)
	{
		this.trainType=trainType;
	}
	
	public double getFare(double distance)
	{
		double basic=2000;
		double add=0.0;
		
		switch(trainType.toLowerCase())
		{
			case "ac":
				add+=50;
				break;
			case "sleeper":
				add+=30;
				break;
		}
		return (basic+add)*distance;
	}
	public String getAmenities()
	{
		String aminities="Seat";
		String extra=" ";
		switch(trainType.toLowerCase())
		{
			case "ac":
				extra="wifi Ac";
				break;
			case "sleeper":
				extra="wifi";
				break;
		}
		return aminities+extra;
	}
}



class Flight implements Fare
{
	private String flightType;
	
	public Flight(String flightType)
	{
		this.flightType=flightType;
	}
	
	public double getFare(double distance)
	{
		double basic=5000;
		double add=0.0;
		
		switch(flightType.toLowerCase())
		{
			case "economy":
				add+=5000;
				break;
			case "business":
				add+=3000;
				break;
		}
		return (basic+add)*distance;
	}
	public String getAmenities()
	{
		String aminities="Seat";
		String extra=" ";
		switch(flightType.toLowerCase())
		{
			case "ac":
				extra="food newspaper";
				break;
			case "sleeper":
				extra="food";
				break;
		}
		return aminities+extra;
	}
}


public class Travel
{	
	public static void main(String args[])
	{	
		double distance=500.0;
		Bus bus=new Bus("ac");
		Train train=new Train("sleeper");
		Flight flight=new Flight("business");
		System.out.println("Bus Fare: $" + bus.getFare(distance));
        System.out.println(bus.getAmenities());

        System.out.println("\nTrain Fare: $" + train.getFare(distance));
        System.out.println(train.getAmenities());

        System.out.println("\nFlight Fare: $" + flight.getFare(distance));
        System.out.println(flight.getAmenities());
       }
 }
		
