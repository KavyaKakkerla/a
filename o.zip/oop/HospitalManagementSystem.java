import java.util.ArrayList;
import java.util.Scanner;

class Patient {
    int id;
    String name;
    int age;
    String disease;

    public Patient(int id, String name, int age, String disease) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.disease = disease;
    }

    public void displayPatientDetails() {
        System.out.println("Patient ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Disease: " + disease);
    }
}

class Staff {
    int staffId;
    String staffName;
    String designation;

    public Staff(int staffId, String staffName, String designation) {
        this.staffId = staffId;
        this.staffName = staffName;
        this.designation = designation;
    }

    public void displayStaffDetails() {
        System.out.println("Staff ID: " + staffId);
        System.out.println("Name: " + staffName);
        System.out.println("Designation: " + designation);
    }
}

public class HospitalManagementSystem {

    static ArrayList<Patient> patients = new ArrayList<>();
    static ArrayList<Staff> staff = new ArrayList<>();

    public static void addPatient(Scanner sc) {
        System.out.println("Enter Patient ID: ");
        int id = sc.nextInt();
        sc.nextLine(); // Consume newline
        System.out.println("Enter Patient Name: ");
        String name = sc.nextLine();
        System.out.println("Enter Patient Age: ");
        int age = sc.nextInt();
        sc.nextLine(); // Consume newline
        System.out.println("Enter Disease: ");
        String disease = sc.nextLine();

        patients.add(new Patient(id, name, age, disease));
        System.out.println("Patient record added successfully!");
    }

    public static void viewPatients() {
        if (patients.isEmpty()) {
            System.out.println("No patients found!");
        } else {
            for (Patient patient : patients) {
                System.out.println("-------------------------");
                patient.displayPatientDetails();
            }
        }
    }

    public static void addStaff(Scanner sc) {
        System.out.println("Enter Staff ID: ");
        int id = sc.nextInt();
        sc.nextLine(); // Consume newline
        System.out.println("Enter Staff Name: ");
        String name = sc.nextLine();
        System.out.println("Enter Designation: ");
        String designation = sc.nextLine();

        staff.add(new Staff(id, name, designation));
        System.out.println("Staff record added successfully!");
    }

    public static void viewStaff() {
        if (staff.isEmpty()) {
            System.out.println("No staff found!");
        } else {
            for (Staff member : staff) {
                System.out.println("-------------------------");
                member.displayStaffDetails();
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("------------- Hospital Management System -------------");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patients");
            System.out.println("3. Add Staff");
            System.out.println("4. View Staff");
            System.out.println("5. Exit");
            System.out.println("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addPatient(sc);
                    break;
                case 2:
                    viewPatients();
                    break;
                case 3:
                    addStaff(sc);
                    break;
                case 4:
                    viewStaff();
                    break;
                case 5:
                    System.out.println("Exiting the system. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        sc.close();
    }
}
