import java.util.Scanner;


class Account
{
	 String accountName;
	String branchName;
	String bankName;
	int accountNo;
	double accountBalance;
	String accountAddress;
	public Account(int accountNo,String branchName,String bankName,String accountName,double accountBalance,String accountAddress)
	{
		
		this.branchName=branchName;
		this.bankName=bankName;
		this.accountName=accountName;
		this.accountNo=accountNo;
		this.accountBalance=Math.max(accountBalance,1000.0);
		this.accountAddress=accountAddress;
	}
	public void credit(double money)
	{
		accountBalance+=money;
	}
	public void debit(double money)
	{
		if(money<=accountBalance)
		{	
			
			accountBalance-=money;
			System.out.println("The amount is credited");
		}
		else
		{
			System.out.println("Debit amount execeeded account balance");
		}
	}
	public void getBalance()
	{
		System.out.println("The balance is "+accountBalance);
	}
	public void exit()
	{
		System.out.println("exit from the indidvidual transaction");
	}
}
	

public class Bank
{

	

public static void main(String args[])
{
		Scanner sc=new Scanner(System.in);
	
	
        Account a[]=new Account[10];
		int exit = 1;
	//	Scanner sc = new Scanner(System.in);
		a[0]=new Account(2500,"SBI","Basar","Surya",123,"wgl");
		a[1]=new Account(67200,"SBI","Basar","Kanna",124,"hnk");
		a[2]=new Account(6300,"SBI","Basar","Pranav",125,"hyd");
		a[3]=new Account(50002,"SBI","Basar","Mammu",126,"hsn");
		a[4]=new Account(15034,"SBI","Basar","Cutipie",127,"jt");
		a[5]=new Account(18090,"SBI","NZB","USha",1123,"jn");
		a[6]=new Account(50000,"SBI","NZB","Theju",1124,"wgl");
		a[7]=new Account(19001,"SBI","NZB","Ruchuk",1124,"wgl");
		a[8]=new Account(19400,"SBI","NZB","Jashu",1125,"hyd");
		a[9]=new Account(35500,"SBI","NZB","Pragna",1126,"medak");


	
		while(exit!=0){
			System.out.println("Enter Username:(branch name) ");
			String un = sc.next();
			System.out.println("Enter password:(Account number) ");
			int p = sc.nextInt();
			int flag = 0;
			String h;
			for(int i=0;i<10;i++){
				h = a[i].branchName;
				if(h.equals(un) && a[i].accountNo == p){
					flag = 1;
					System.out.println("Welcome your transaction Started");
						System.out.printf("----------------MENU-------------\n");
						System.out.printf("1)Credit\n2)debit\n3)getBalance\n4)exit\n");
						System.out.printf("Choose: ");
						int ch = sc.nextInt();
						switch(ch){
							case 1: System.out.printf("Enter balance to credit: ");
									double b = sc.nextDouble();
									a[i].credit(b);
									break;
							case 2: System.out.printf("Enter balance to debit: ");
									double c = sc.nextDouble();
									a[i].debit(c);
									break;
							case 3: a[i].getBalance();
                           

						}
						System.out.printf("Exit application\nEnter 0 to exit(any other key to continue): ");
						exit = sc.nextInt();
						
				}
			}
			if(flag==0){
				System.out.printf("Account not found\n");
                return;
			}
		}
	}
}


			

							